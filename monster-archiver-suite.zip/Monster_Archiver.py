#!/usr/bin/env python3
"""
Monster Archiver — Nexus Edition v18.4

Audio archiver: fingerprints audio files, fetches metadata and lyrics from
MusicBrainz, iTunes, and Deezer, AI-transcribes vocals via Whisper with
Demucs stem separation, translates lyrics, and writes fully-tagged files.
"""

import os
import sys
import subprocess
import shutil
import re
import time
from glob import glob
import urllib.request
import urllib.parse
import json
import threading
import traceback
import csv
import hashlib
import concurrent.futures
import queue
import sqlite3
import argparse
import shlex
import tempfile
import logging
from collections import OrderedDict

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
VERSION  = "18.4"

# --- CUDA DLL CLEANUP & SAFE LOADING (Windows only) ---
if os.name == 'nt':
    import site
    for pattern in ["cublas*.dll", "cudnn*.dll", "nvblas*.dll"]:
        for bad_dll in glob(os.path.join(BASE_DIR, pattern)):
            try: os.remove(bad_dll)
            except Exception: pass
    try:
        sp_dirs = getattr(site, 'getsitepackages', lambda: [])()
        if hasattr(site, 'getusersitepackages'):
            try: sp_dirs.append(site.getusersitepackages())
            except Exception: pass
        for sp in sp_dirs:
            nvidia_dir = os.path.join(sp, "nvidia")
            if os.path.isdir(nvidia_dir):
                for subdir in os.listdir(nvidia_dir):
                    bin_path = os.path.join(nvidia_dir, subdir, "bin")
                    if os.path.isdir(bin_path):
                        os.environ["PATH"] = bin_path + os.pathsep + os.environ.get("PATH", "")
                        if hasattr(os, 'add_dll_directory'):
                            try: os.add_dll_directory(bin_path)
                            except Exception: pass
    except Exception: pass

# ---------------- CONFIGURATION LAYER ----------------
CONFIG_FILE = os.path.join(BASE_DIR, "config.json")
DEFAULT_CONFIG = {
    "MAX_WORKERS": 4,
    "ACOUSTID_API_KEY": "",
    "DEFAULT_TRANSLATION_ENGINE": "1",
    "VRAM_SAFE_MODE": True,
    "DEBUG_MODE": False,
    "WORD_LEVEL_LRC": True,
    "DEMUCS_MODEL": "htdemucs_ft",
    "KEY_NOTATION": "text",
    "LOCAL_LLM_BASE_URL": "http://localhost:11434/v1",
    "LOCAL_LLM_MODEL": "gemma4:12b",
    "LOCAL_LLM_THINK": False,
    "LOCAL_LLM_BATCH_SIZE": 8,
    "LOCAL_LLM_MAX_LINE_CHARS": 800,
    "MUSICBRAINZ_CONTACT_EMAIL": "",
    "PHONETIC_CORRECTIONS": {
        "i wish i could do it when i'm on my own": "I wish I could do well when I'm on my own",
        "i wish i could do it": "I wish I could do well",
        "a lot of steps to your favorite song": "I learned the steps to your favorite song",
        "a lot of steps": "I learned the steps",
        "so magic how i feel": "So imagine how I feel",
        "so magic how": "So imagine how",
        "when i come in you're not here": "when I come and you're not here"
    },
    "LRC_OFFSET_MS": 0,
    "REJECT_LOSSY_UPCONVERT": False,
    "UPCONVERT_ENERGY_THRESHOLD": 0.999,  # Default adjusted to prevent false-positives
    "WHISPER_MODEL_SIZE": "large-v3",
    "WHISPER_COMPUTE_TYPE": "",
    "WHISPER_BEST_OF": 1,
    "WHISPER_BEAM_SIZE": 5,
    "WHISPER_PATIENCE": 1.5,
    "WHISPER_TEMPERATURE_STEPS": [0.0, 0.2, 0.4, 0.6],
    "WHISPER_LOGPROB_THRESHOLD": -1.5,
    "WHISPER_CONDITION_ON_PREV": False,
    "WHISPER_VAD_THRESHOLD": 0.15,
    "WHISPER_VAD_MIN_SILENCE_MS": 500,
    "WHISPER_VAD_SPEECH_PAD_MS": 600,
    "WHISPER_VAD_MIN_SPEECH_MS": 100,
    "WHISPER_VAD_MAX_SPEECH_S": 60,
    "WHISPER_NO_SPEECH_THRESHOLD": 0.80,
    "WHISPER_NO_SPEECH_THRESHOLD_RELAXED": 0.90,
    "WHISPER_COMPRESSION_RATIO": 2.6,
    "WHISPER_COMPRESSION_RATIO_RELAXED": 3.0,
    "WHISPER_NO_SPEECH_PROB_FILTER": 0.95,
}

_CAMELOT_MAP = {
    "C major": "8B", "G major": "9B", "D major": "10B", "A major": "11B", "E major": "12B", "B major": "1B",
    "F# major": "2B", "C# major": "3B", "Ab major": "4B", "Eb major": "5B", "Bb major": "6B", "F major": "7B",
    "A minor": "8A", "E minor": "9A", "B minor": "10A", "F# minor": "11A", "C# minor": "12A", "Ab minor": "1A",
    "Eb minor": "2A", "Bb minor": "3A", "F minor": "4A", "C minor": "5A", "G minor": "6A", "D minor": "7A"
}
_OPENKEY_MAP = {
    "C major": "1d", "G major": "2d", "D major": "3d", "A major": "4d", "E major": "5d", "B major": "6d",
    "F# major": "7d", "C# major": "8d", "Ab major": "9d", "Eb major": "10d", "Bb major": "11d", "F major": "12d",
    "A minor": "1m", "E minor": "2m", "B minor": "3m", "F# minor": "4m", "C# minor": "5m", "Ab minor": "6m",
    "Eb minor": "7m", "Bb minor": "8m", "F minor": "9m", "C minor": "10m", "G minor": "11m", "D minor": "12m"
}
_ISO_639_1_TO_2T = {
    "en": "eng", "ja": "jpn", "ko": "kor", "zh": "chi", "es": "spa", "fr": "fre", "de": "ger", "it": "ita",
    "pt": "por", "ru": "rus", "ar": "ara", "hi": "hin", "th": "tha", "vi": "vie", "id": "ind", "tr": "tur"
}

def load_config():
    if not os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "w") as f:
            json.dump(DEFAULT_CONFIG, f, indent=4)
    with open(CONFIG_FILE, "r") as f:
        conf = json.load(f)
    updated = False
    for k, v in DEFAULT_CONFIG.items():
        if k not in conf:
            conf[k] = v
            updated = True
    if updated:
        with open(CONFIG_FILE, "w") as f:
            json.dump(conf, f, indent=4)
    return conf

CONF = load_config()

# ---------------- AUTO-INSTALLER ----------------
def ensure_dependencies():
    deps = {
        "rich": "rich", "mutagen": "mutagen", "requests": "requests",
        "syncedlyrics": "syncedlyrics", "deep-translator": "deep_translator",
        "pyacoustid": "acoustid", "musicbrainzngs": "musicbrainzngs",
        "imageio-ffmpeg": "imageio_ffmpeg", "librosa": "librosa", "numpy": "numpy"
    }
    missing = [p for p, i in deps.items() if not shutil.which(i) and not import_success(i)]
    if missing:
        print(f"Installing missing dependencies: {missing}...")
        subprocess.check_call([sys.executable, "-m", "pip", "install"] + missing)

def import_success(name):
    try:
        __import__(name)
        return True
    except ImportError:
        return False

ensure_dependencies()

# ---------------- FFMPEG INJECTION ----------------
try:
    import imageio_ffmpeg
    pip_ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
    local_ffmpeg = os.path.join(BASE_DIR, "ffmpeg.exe" if os.name == 'nt' else "ffmpeg")
    if not os.path.exists(local_ffmpeg):
        shutil.copy2(pip_ffmpeg, local_ffmpeg)
    if BASE_DIR not in os.environ.get("PATH", "").split(os.pathsep):
        os.environ["PATH"] = BASE_DIR + os.pathsep + os.environ.get("PATH", "")
except Exception: pass

import numpy as np
import requests
import acoustid
import syncedlyrics
import mutagen
import musicbrainzngs
import librosa
import torch
from mutagen.flac import FLAC, Picture
from mutagen.mp3 import MP3
from mutagen.id3 import ID3, APIC, USLT, SYLT, TCON, TCOM, TPE1, TPE2, TEXT, TBPM, TKEY, TPOS, TSRC, TLAN, TXXX
from mutagen.mp4 import MP4, MP4Cover, MP4FreeForm, AtomDataType
from deep_translator import GoogleTranslator, MyMemoryTranslator
from rich.console import Console
from rich.prompt import Prompt
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich import box

# --- API SETUP & LOGS ---
musicbrainzngs.set_useragent("MonsterArchiver", VERSION, CONF.get("MUSICBRAINZ_CONTACT_EMAIL", ""))
console = Console()
cli_lock = threading.Lock()
ui_lock = threading.Lock()
translation_lock = threading.Lock()
gpu_lock = threading.Lock()
_db_lock = threading.Lock()
_input_queue = queue.Queue()

GLOBAL_TRANS_METHOD = CONF["DEFAULT_TRANSLATION_ENGINE"]
GLOBAL_AUDIO_LANG = "auto"
GLOBAL_ENABLE_LYRICS = True
GLOBAL_DRY_RUN = False
worker_status = {}
active_live_ui = None

# Paths
MUSIC_DIR = os.path.join(os.path.expanduser("~"), "Music", "Monster_Library")
LOGS_DIR = os.path.join(MUSIC_DIR, ".logs")
DB_FILE = os.path.join(LOGS_DIR, "archiver.sqlite")
_DEFAULT_WATCH_PATH = os.path.join(os.path.expanduser("~"), "Downloads")

for d in (MUSIC_DIR, LOGS_DIR):
    os.makedirs(d, exist_ok=True)

# ---------------- DATABASE ----------------
def init_db():
    with _db_lock, sqlite3.connect(DB_FILE) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS downloads (
                vid TEXT PRIMARY KEY, title TEXT, status TEXT, file_path TEXT, timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS fingerprints (
                fingerprint TEXT PRIMARY KEY, title TEXT, artist TEXT, library_path TEXT, timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)

def db_log_status(vid, title, status, file_path=None):
    try:
        with _db_lock, sqlite3.connect(DB_FILE) as conn:
            conn.execute("INSERT OR REPLACE INTO downloads (vid, title, status, file_path) VALUES (?, ?, ?, ?)", (vid, title, status, file_path))
    except Exception as e: log(f"DB Write error: {e}", "red")

def get_failed_entries():
    try:
        with _db_lock, sqlite3.connect(DB_FILE) as conn:
            return conn.execute("SELECT vid, title, file_path FROM downloads WHERE status LIKE 'FAILED%'").fetchall()
    except Exception: return []

def is_processed(vid):
    try:
        with _db_lock, sqlite3.connect(DB_FILE) as conn:
            row = conn.execute("SELECT status FROM downloads WHERE vid=?", (vid,)).fetchone()
            return bool(row and row[0] in ("SUCCESS", "DUPLICATE"))
    except Exception: return False

def check_acoustic_duplicate(fp):
    if not fp: return None
    try:
        with _db_lock, sqlite3.connect(DB_FILE) as conn:
            row = conn.execute("SELECT title, artist, library_path FROM fingerprints WHERE fingerprint=?", (str(fp),)).fetchone()
            if row: return {"title": row[0], "artist": row[1], "path": row[2]}
    except Exception: pass
    return None

def store_fingerprint(fp, title, artist, lib_path):
    if not fp: return
    try:
        with _db_lock, sqlite3.connect(DB_FILE) as conn:
            conn.execute("INSERT OR REPLACE INTO fingerprints (fingerprint, title, artist, library_path) VALUES (?, ?, ?, ?)", (str(fp), title, artist, lib_path))
    except Exception: pass

init_db()

# ---------------- HELPERS ----------------
def log(msg, style="bold white"):
    ts = time.strftime("%H:%M:%S")
    formatted = f"[dim]{ts}[/dim] {msg}"
    with cli_lock:
        if active_live_ui and active_live_ui.is_started:
            active_live_ui.console.print(formatted, style=style)
        else:
            console.print(formatted, style=style)

_WINDOWS_RESERVED_NAMES = frozenset({'CON', 'PRN', 'AUX', 'NUL'})

def sanitize_filename(s, maxlen=100):
    if not s: return "Unknown"
    s = str(s).replace('"', '').replace('\x00', '')
    s = re.sub(r'[<>:/\\|?*]', '', s)
    s = re.sub(r'\s+', ' ', s).strip()
    s = s.strip('.')[:maxlen]
    if s.upper() in _WINDOWS_RESERVED_NAMES:
        s += "_"
    return s if s else "Unknown"

def get_audio_duration(path):
    try:
        probe = mutagen.File(path)
        if probe and probe.info: return float(probe.info.length)
    except Exception: pass
    try: return float(librosa.get_duration(path=path))
    except Exception: return 0.0

def _librosa_load_safe(path, sr=22050, mono=True, offset=0.0, duration=None):
    import io, soundfile as _sf
    ffmpeg_exe = "ffmpeg"
    cmd = [ffmpeg_exe, "-y", "-hide_banner", "-loglevel", "error"]
    if offset > 0.0: cmd += ["-ss", str(offset)]
    cmd += ["-i", path]
    if duration is not None: cmd += ["-t", str(duration)]
    if mono: cmd += ["-ac", "1"]
    if sr: cmd += ["-ar", str(sr)]
    cmd += ["-f", "wav", "-"]
    try:
        res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, check=True)
        y, file_sr = _sf.read(io.BytesIO(res.stdout), dtype="float32")
        if y.ndim == 2 and mono: y = y.mean(axis=1)
        return y, file_sr
    except Exception:
        import warnings
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            return librosa.load(path, sr=sr, mono=mono, offset=offset, duration=duration)

# ---------------- SPECTRAL FALSE-POSITIVE RESOLUTION (FIX #1) ----------------
def detect_lossy_upconvert(file_path):
    """
    Detect fake lossless (upconverted MP3/AAC) files with high precision,
    eliminating false-positives on warm or organic real FLAC files.
    """
    ext = os.path.splitext(file_path)[1].lstrip('.').lower()
    if ext not in ['flac', 'wav', 'aiff', 'alac']:
        return None

    threshold = float(CONF.get("UPCONVERT_ENERGY_THRESHOLD", 0.999))
    try:
        probe_duration = get_audio_duration(file_path)
        offset = max(0.0, (probe_duration - 30.0) / 2) if probe_duration > 30 else 0.0
        
        y, sr = _librosa_load_safe(file_path, sr=None, mono=True, offset=offset, duration=30.0)
        if len(y) == 0: return None

        S = np.abs(librosa.stft(y)) ** 2
        freqs = librosa.fft_frequencies(sr=sr)
        power_per_bin = S.mean(axis=1)
        total_power = power_per_bin.sum()
        if total_power <= 0: return None

        # Convert to dB relative to peak to locate sharp spectral low-pass cuts
        S_db = librosa.amplitude_to_db(np.sqrt(S), ref=np.max)
        bin_db_95 = np.percentile(S_db, 95, axis=1) # 95th percentile dB level per bin over time

        # Find max frequency carrying any real signal above standard noise floors (-65 dB)
        active_bins = freqs[bin_db_95 > -65]
        max_active_freq = active_bins[-1] if len(active_bins) > 0 else 0.0

        low_mask = freqs < 16000
        low_power = power_per_bin[low_mask].sum()
        ratio = float(low_power / total_power)

        # A lossy upconvert is flagged if the high frequency cutoff is below 18.5kHz
        # AND the proportion of energy below 16kHz is virtually absolute (>99.9%)
        suspect = (max_active_freq < 18500) and (ratio >= threshold)

        return {
            "suspect": suspect,
            "energy_below_16k": ratio,
            "max_active_freq_hz": float(max_active_freq),
            "threshold_used": threshold
        }
    except Exception as e:
        if CONF.get("DEBUG_MODE"): log(f"Lossy upconvert check error: {e}", "yellow")
        return None

def get_audio_quality_score(file_path):
    ext = os.path.splitext(file_path)[1].lstrip('.').lower()
    rank = {'flac': 5, 'wav': 5, 'alac': 5, 'm4a': 3, 'mp3': 2}.get(ext, 1)
    if rank == 5: return (5, 9999)
    try:
        probe = mutagen.File(file_path)
        bitrate = int(getattr(probe.info, 'bitrate', 0) or 0) // 1000
        return (rank, bitrate)
    except Exception: return (0, 0)

# ---------------- COVERS REPLACEMENT & HIGH RESOLUTION (FIX #2) ----------------
def remove_and_replace_cover(filepath, img_data, mime_type):
    """
    Forcefully strips and deletes ANY pre-existing covers (hardcoded, secondary,
    or thumbnail blocks) from the audio container before embedding the new cover.
    """
    ext = os.path.splitext(filepath)[1].lstrip('.').lower()
    try:
        if ext == "flac":
            audio = FLAC(filepath)
            audio.clear_pictures()
            audio.pictures = []
            if img_data:
                pic = Picture()
                pic.type = 3
                pic.mime = mime_type
                pic.data = img_data
                audio.add_picture(pic)
            audio.save()
        elif ext == "mp3":
            audio = MP3(filepath, ID3=ID3)
            if audio.tags is None: audio.add_tags()
            audio.tags.delall('APIC')
            if img_data:
                audio.tags.add(APIC(encoding=3, mime=mime_type, type=3, desc='Cover', data=img_data))
            audio.save()
        elif ext in ("m4a", "aac"):
            audio = MP4(filepath)
            if audio.tags is None: audio.add_tags()
            if 'covr' in audio.tags:
                del audio.tags['covr']
            if img_data:
                fmt = MP4Cover.FORMAT_PNG if "png" in mime_type else MP4Cover.FORMAT_JPEG
                audio.tags['covr'] = [MP4Cover(img_data, imageformat=fmt)]
            audio.save()
    except Exception as e:
        log(f"Failed to force replace cover for {os.path.basename(filepath)}: {e}", "red")

def download_high_res_cover(cover_url):
    """
    Tries to retrieve the maximum uploaded image resolution via CDN fallback logic.
    Cascades down from maximum to standard resolution options if the CDN throws 404/times out.
    """
    if not cover_url: return None, "image/jpeg"
    
    # Cascade list of fallback sizes to avoid 'stuck covers' or dead URLs
    urls_to_try = [cover_url]
    if "mzstatic.com" in cover_url or "apple.com" in cover_url:
        # iTunes CDN URL size substitution
        base_url = re.sub(r'/\d+x\d+bb\.(jpg|png)', r'/SIZE_PLACEHOLDERbb.jpg', cover_url)
        if base_url != cover_url:
            urls_to_try = [
                base_url.replace("SIZE_PLACEHOLDER", "100000x100000"), # Apple master original upload
                base_url.replace("SIZE_PLACEHOLDER", "2000x2000"),
                base_url.replace("SIZE_PLACEHOLDER", "1400x1400"),
                base_url.replace("SIZE_PLACEHOLDER", "1000x1000"),
                base_url.replace("SIZE_PLACEHOLDER", "600x600")
            ]

    for url in urls_to_try:
        try:
            res = requests.get(url, headers={'User-Agent': 'Mozilla/5.0'}, timeout=15)
            if res.status_code == 200:
                ct = res.headers.get("Content-Type", "image/jpeg").split(";")[0].strip().lower()
                mime = ct if ct in ("image/jpeg", "image/png", "image/webp") else "image/jpeg"
                return res.content, mime
        except Exception: continue
    return None, "image/jpeg"

# ---------------- METADATA FETCH LAYER ----------------
def fetch_smart_metadata(title, artist, worker_idx):
    clean_title = re.sub(r'\(.*?\)|\[.*?\]|\b(?:official|video|audio|mv)\b', '', title, flags=re.IGNORECASE).strip()
    clean_title = re.sub(r'^\d+\s*[-\.]\s*', '', clean_title).strip()
    
    # Concurrently lookup MusicBrainz + iTunes APIs to cut fetch times in half
    results = []
    
    def fetch_mb():
        try:
            q = f'recording:"{clean_title}"'
            if artist and artist != "Unknown": q += f' AND artist:"{artist}"'
            mb_data = musicbrainzngs.search_recordings(query=q, limit=3)
            hits = []
            for rec in mb_data.get('recording-list', []):
                rel = rec.get('release-list', [{}])[0]
                release_mbid = rel.get('id', '')
                cover_url = f"https://coverartarchive.org/release/{release_mbid}/front" if release_mbid else ""
                hits.append({
                    "source": "MusicBrainz", "title": rec.get('title', 'Unknown'),
                    "artist": rec.get('artist-credit-phrase', 'Unknown'),
                    "artist_list": [ac['artist']['name'] for ac in rec.get('artist-credit', []) if 'artist' in ac],
                    "album": rel.get('title', 'Unknown Album'),
                    "year": rel.get('date', '')[:4] or "Unknown",
                    "track": rec.get('release-list', [{}])[0].get('medium-list', [{}])[0].get('track-list', [{}])[0].get('number', '1'),
                    "genre": rec.get('tag-list', [{}])[0].get('name', 'Unknown').title(),
                    "composer": "Unknown", "lyricist": "Unknown", "cover": cover_url,
                    "release_type": rel.get('release-group', {}).get('type', 'Album')
                })
            return hits
        except Exception: return []

    def fetch_itunes():
        try:
            term = urllib.parse.quote(f"{clean_title} {artist}" if artist != "Unknown" else clean_title)
            r = requests.get(f"https://itunes.apple.com/search?term={term}&entity=song&limit=3", headers={'User-Agent': 'Mozilla/5.0'}, timeout=8).json()
            hits = []
            for t in r.get("results", []):
                rel_date = t.get("releaseDate", "")
                raw_art = t.get("artworkUrl100", "")
                # Convert standard sizes to our unified extreme/high resolution string pattern
                hq_art = re.sub(r'\d+x\d+bb\.(jpg|png)', r'100000x100000bb.\1', raw_art) if raw_art else ""
                hits.append({
                    "source": "iTunes", "title": t.get("trackName", "Unknown"),
                    "artist": t.get("artistName", "Unknown"), "artist_list": [t.get("artistName", "Unknown")],
                    "album": t.get("collectionName", "Unknown"), "year": rel_date[:4] or "Unknown",
                    "track": str(t.get("trackNumber", "1")), "genre": t.get("primaryGenreName", "Unknown"),
                    "composer": t.get("composerName") or "Unknown", "lyricist": "Unknown", "cover": hq_art,
                    "release_type": "Album"
                })
            return hits
        except Exception: return []

    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
        f_mb = executor.submit(fetch_mb)
        f_it = executor.submit(fetch_itunes)
        results.extend(f_mb.result())
        results.extend(f_it.result())

    selected_meta = {
        "title": title, "artist": artist, "artist_list": [artist], "album": "Unknown Album",
        "year": "Unknown Year", "track": "1", "genre": "Unknown", "composer": "Unknown",
        "lyricist": "Unknown", "cover": "", "release_type": "Unknown"
    }
    if len(results) == 1:
        selected_meta.update(results[0])
    elif len(results) > 1:
        update_ui(worker_idx, msg="[bold yellow]Awaiting Metadata Choice[/bold yellow]")
        tbl = Table(title=f"Multiple Matches for {title}", box=box.ROUNDED)
        tbl.add_column("Key", style="bold red")
        tbl.add_column("Source")
        tbl.add_column("Title")
        tbl.add_column("Artist")
        tbl.add_column("Album")
        for i, r in enumerate(results):
            tbl.add_row(str(i+1), r["source"], r["title"], r["artist"], r["album"])
        
        c = pause_ui_and_ask("Select Match (1-N) or 0 to skip:", choices=[str(x) for x in range(len(results)+1)], default="1", table_to_print=tbl)
        if c != "0":
            selected_meta.update(results[int(c)-1])
    return selected_meta

# ---------------- CORES & TRANSCRIPTION ----------------
def isolate_vocals_with_demucs(file_path, vid, worker_idx):
    out_dir = os.path.join(LOGS_DIR, f"{vid}_demucs")
    os.makedirs(out_dir, exist_ok=True)
    update_ui(worker_idx, msg="Demucs Stem Isolation...")
    cmd = [
        sys.executable, "-m", "demucs.separate",
        "-n", CONF.get("DEMUCS_MODEL", "htdemucs_ft"),
        "--two-stems=vocals",
        "-d", "cuda" if torch.cuda.is_available() else "cpu",
        "-o", out_dir, file_path
    ]
    try:
        if CONF.get("VRAM_SAFE_MODE", True):
            with gpu_lock:
                subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
        else:
            subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
        vocals = glob(os.path.join(out_dir, "**", "vocals.*"), recursive=True)
        if vocals: return vocals[0], out_dir
    except Exception: pass
    return None, out_dir

def transcribe_audio(file_path, vid, worker_idx, meta_dict=None):
    # Dynamic loader of whisper to minimize process boot footprint
    from faster_whisper import WhisperModel
    update_ui(worker_idx, msg="AI Whisper Transcribe...")
    try:
        vocals, d_dir = isolate_vocals_with_demucs(file_path, vid, worker_idx)
        target = vocals if vocals else file_path
        
        device = "cuda" if torch.cuda.is_available() else "cpu"
        model = WhisperModel(CONF["WHISPER_MODEL_SIZE"], device=device, compute_type="int8_float16" if device == "cuda" else "int8")
        
        with gpu_lock:
            segs, info = model.transcribe(
                target,
                vad_filter=True,
                no_speech_threshold=CONF["WHISPER_NO_SPEECH_THRESHOLD"],
                compression_ratio_threshold=CONF["WHISPER_COMPRESSION_RATIO"]
            )
            segs = list(segs)
        
        lines = []
        for s in segs:
            ts = f"[{int(s.start // 60):02d}:{s.start % 60:05.2f}]"
            lines.append(f"{ts}{s.text.strip()}\n")
            
        if d_dir and os.path.exists(d_dir):
            shutil.rmtree(d_dir, ignore_errors=True)
            
        if not lines: return None
        
        out_path = os.path.join(LOGS_DIR, f"{vid}_lyrics.lrc")
        with open(out_path, "w", encoding="utf-8") as f:
            f.writelines(lines)
        return out_path
    except Exception as e:
        if CONF.get("DEBUG_MODE"): log(f"Whisper Transcription Error: {e}", "red")
        return None

# ---------------- LYRICS DB LOOKUP ----------------
def fetch_ultimate_lyrics(title, artist, vid, worker_idx, audio_path=None):
    options = []
    try:
        # Step 1: LRCLIB API fetch
        term = urllib.parse.quote(f"{title} {artist}")
        res = requests.get(f"https://lrclib.net/api/search?q={term}", headers={'User-Agent': 'MonsterArchiver'}, timeout=10).json()
        if res:
            for t in res[:3]:
                txt = t.get('syncedLyrics') or t.get('plainLyrics')
                if txt:
                    options.append({
                        "source": "LRCLIB", "synced": bool(t.get('syncedLyrics')),
                        "text": txt, "title": t.get('name', 'Unknown'), "artist": t.get('artist', 'Unknown')
                    })
    except Exception: pass

    # Musixmatch / Syncedlyrics fallback
    try:
        txt = syncedlyrics.search(f"{title} {artist}")
        if txt:
            options.append({
                "source": "Musixmatch", "synced": "[" in txt,
                "text": txt, "title": title, "artist": artist
            })
    except Exception: pass

    if not options: return None
    
    update_ui(worker_idx, msg="Select Lyrics Option")
    tbl = Table(title=f"Lyrics Found for {title}", box=box.ROUNDED)
    tbl.add_column("Key", style="bold red")
    tbl.add_column("Source")
    tbl.add_column("Type")
    tbl.add_column("Track")
    for i, o in enumerate(options):
        tbl.add_row(str(i+1), o["source"], "Synced" if o["synced"] else "Plain", o["title"])
        
    c = pause_ui_and_ask("Select Lyrics (1-N) or A for Whisper, 0 to skip:", choices=[str(x) for x in range(len(options)+1)] + ["A", "a"], default="1", table_to_print=tbl)
    if c.lower() == "a": return None
    if c == "0": return "SKIP"
    
    opt = options[int(c)-1]
    out_path = os.path.join(LOGS_DIR, f"{vid}_lyrics.lrc")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(opt["text"])
    return out_path

# ---------------- PIPELINE & TAGGING ----------------
def process_local_file(file_path, worker_idx, force=False, stats=None):
    vid = "LOC_" + hashlib.md5(file_path.encode('utf-8')).hexdigest()[:16]
    title = os.path.splitext(os.path.basename(file_path))[0]
    artist = "Unknown"
    
    try:
        audio_meta = mutagen.File(file_path, easy=True)
        if audio_meta:
            title = audio_meta.get('title', [title])[0]
            artist = audio_meta.get('artist', [artist])[0]
    except Exception: pass

    if is_processed(vid) and not force:
        update_ui(worker_idx, msg="Skipped (Already Processed)")
        if stats: stats.record_skipped()
        return

    # Spectrum False-Positive Analysis Check (FIX #1)
    update_ui(worker_idx, msg="Scanning Spectral Quality...")
    upconv_res = detect_lossy_upconvert(file_path)
    if upconv_res and upconv_res["suspect"]:
        warn_msg = f"⚠ LOSS SPECTRAL CEILING CUTOFF WARNING: {title} is likely upconverted (Cutoff: {upconv_res['max_active_freq_hz']:.0f}Hz)"
        log(warn_msg, "bold red")
        if CONF.get("REJECT_LOSSY_UPCONVERT", False):
            db_log_status(vid, title, "FAILED: lossy upconvert", file_path)
            if stats: stats.record_failed()
            return

    # Check Acoustic Duplicate
    fp_meta, raw_fp = get_metadata_via_fingerprint(file_path)
    if fp_meta:
        title = fp_meta.get('title', title)
        artist = fp_meta.get('artist', artist)

    if raw_fp:
        dup = check_acoustic_duplicate(raw_fp)
        if dup and not force:
            log(f"Acoustic duplicate found: {title} already exists in {dup['path']}", "yellow")
            if stats: stats.record_skipped()
            return

    # Query Meta & Setup high-quality cover
    meta = fetch_smart_metadata(title, artist, worker_idx)
    img_data, mime_type = None, "image/jpeg"
    if meta.get("cover"):
        img_data, mime_type = download_high_res_cover(meta["cover"])

    # Lyrics Block
    lrc_path = None
    if GLOBAL_ENABLE_LYRICS:
        lrc_path = fetch_ultimate_lyrics(meta["title"], meta["artist"], vid, worker_idx, file_path)
        if lrc_path == "SKIP": lrc_path = None
        elif not lrc_path:
            lrc_path = transcribe_audio(file_path, vid, worker_idx, meta)

    # Move, Wipe cover blocks explicitly, and Embed fresh tagging (FIX #2)
    ext = os.path.splitext(file_path)[1].lstrip('.').lower()
    dest_dir = os.path.join(MUSIC_DIR, sanitize_filename(meta["artist"], 40), f"{meta['year']} - {sanitize_filename(meta['album'], 50)}")
    os.makedirs(dest_dir, exist_ok=True)
    
    dest_file = os.path.join(dest_dir, f"{int(meta['track']):02d} - {sanitize_filename(meta['title'], 60)}.{ext}")
    shutil.copy2(file_path, dest_file)
    
    # 1. Strip pre-existing blocks completely first
    remove_and_replace_cover(dest_file, img_data, mime_type)
    
    # 2. Re-apply easy tagging properties
    try:
        audio = mutagen.File(dest_file, easy=True)
        if audio is not None:
            audio["title"] = meta["title"]
            audio["artist"] = meta["artist_list"]
            audio["album"] = meta["album"]
            audio["date"] = meta["year"]
            audio["tracknumber"] = str(meta["track"])
            audio["genre"] = meta["genre"]
            if meta.get("composer") and meta["composer"] != "Unknown": audio["composer"] = meta["composer"]
            audio.save()
    except Exception as e: log(f"Tag error: {e}", "red")

    if raw_fp:
        store_fingerprint(raw_fp, meta["title"], meta["artist"], dest_file)
        
    db_log_status(vid, meta["title"], "SUCCESS", dest_file)
    if stats: stats.record_processed()
    update_ui(worker_idx, msg="[bold green]Success[/bold green]")

def get_metadata_via_fingerprint(file_path):
    try:
        dur, fp = acoustid.fingerprint_file(file_path)
        if not CONF.get("ACOUSTID_API_KEY"): return None, fp
        res = acoustid.lookup(CONF["ACOUSTID_API_KEY"], fp, dur, meta='recordings+artists')
        if res.get('results'):
            top = res['results'][0]
            if top.get('score', 0) > 0.6:
                rec = top['recordings'][0]
                return {"title": rec.get("title"), "artist": rec.get("artists", [{}])[0].get("name")}, fp
        return None, fp
    except Exception: return None, None

# ---------------- CORE MANAGEMENT WORKERS ----------------
class BatchStats:
    def __init__(self):
        self.processed = 0
        self.skipped = 0
        self.failed = 0
    def record_processed(self): self.processed += 1
    def record_skipped(self): self.skipped += 1
    def record_failed(self): self.failed += 1
    def print_summary(self):
        console.print(Panel(
            f"[bold green]Processed: {self.processed}[/bold green] | "
            f"[bold yellow]Skipped: {self.skipped}[/bold yellow] | "
            f"[bold red]Failed: {self.failed}[/bold red]",
            title="Session Stats"
        ))

def generate_dashboard_table():
    tbl = Table(box=box.SIMPLE_HEAD, expand=True)
    tbl.add_column("Worker", style="cyan")
    tbl.add_column("Status", style="magenta")
    with ui_lock:
        for idx in range(CONF["MAX_WORKERS"]):
            st = worker_status.get(idx, "Idle")
            tbl.add_row(f"Thread-{idx+1}", st)
    return Panel(tbl, title=f"Monster Archiver v{VERSION}")

def update_ui(idx, vid=None, msg=None):
    with ui_lock:
        worker_status[idx] = msg if msg else "Idle"

def pause_ui_and_ask(prompt_msg, choices=None, default="1", table_to_print=None):
    if table_to_print:
        with cli_lock: console.print(table_to_print)
    return Prompt.ask(prompt_msg, choices=choices, default=default)

def run_library_scan():
    console.print("[bold cyan]Scanning Monster Library for health & tags...[/bold cyan]")
    issues = []
    for root, _, files in os.walk(MUSIC_DIR):
        for f in files:
            if f.lower().endswith(('.mp3', '.flac', '.m4a')):
                path = os.path.join(root, f)
                file_issues = []
                try:
                    audio = mutagen.File(path, easy=True)
                    if not audio: file_issues.append("Unreadable tags")
                    else:
                        if not audio.get("genre"): file_issues.append("Missing Genre")
                        if not audio.get("date"): file_issues.append("Missing Year")
                except Exception: file_issues.append("Parse error")
                
                # Check cover existence
                img, _ = _extract_embedded_art(path)
                if not img: file_issues.append("Missing Album Art")
                
                if file_issues:
                    issues.append((path, file_issues))
                    
    if issues:
        tbl = Table(title="Library Integrity Issues", box=box.ROUNDED)
        tbl.add_column("File", style="cyan")
        tbl.add_column("Flaws", style="red")
        for p, flaws in issues[:50]:
            tbl.add_row(os.path.basename(p), ", ".join(flaws))
        console.print(tbl)
    else:
        console.print("[bold green]All scanned files are completely clean and fully embedded![/bold green]")

def _extract_embedded_art(file_path):
    try:
        ext = os.path.splitext(file_path)[1].lstrip('.').lower()
        if ext == 'flac':
            audio = FLAC(file_path)
            if audio.pictures: return audio.pictures[0].data, audio.pictures[0].mime
        elif ext == 'mp3':
            audio = MP3(file_path, ID3=ID3)
            apics = audio.tags.getall('APIC')
            if apics: return apics[0].data, apics[0].mime
        elif ext in ('m4a', 'aac'):
            audio = MP4(file_path)
            if 'covr' in audio.tags: return bytes(audio.tags['covr'][0]), "image/jpeg"
    except Exception: pass
    return None, None

def main():
    parser = argparse.ArgumentParser(description="Monster Archiver — Nexus Edition")
    parser.add_argument("--scan", action="store_true", help="Walk Library and check metadata state")
    parser.add_argument("--force", action="store_true", help="Force tag overrides")
    args = parser.parse_args()

    if args.scan:
        run_library_scan()
        return

    console.print(Panel("[bold green]Monster Archiver — Nexus Edition v18.4[/bold green]\nCLI interactive wizard booting up...", title="System Engine Ready"))
    
    stats = BatchStats()
    global active_live_ui
    
    try:
        while True:
            path = console.input("\n[bold yellow]Drag & Drop audio file or directory to process (or 'q' to quit): [/bold yellow]").strip()
            if path.lower() in ('q', 'quit'): break
            if not os.path.exists(path):
                console.print("[bold red]Invalid file path![/bold red]")
                continue
                
            tasks = []
            if os.path.isdir(path):
                for root, _, files in os.walk(path):
                    for f in files:
                        if f.lower().endswith(('.mp3', '.flac', '.m4a')):
                            tasks.append(os.path.join(root, f))
            else:
                tasks.append(path)
                
            if not tasks:
                console.print("[bold red]No valid audio files found![/bold red]")
                continue
                
            with Live(generate_dashboard_table(), refresh_per_second=2) as live:
                active_live_ui = live
                with concurrent.futures.ThreadPoolExecutor(max_workers=CONF["MAX_WORKERS"]) as executor:
                    futures = [executor.submit(process_local_file, f, idx % CONF["MAX_WORKERS"], force=args.force, stats=stats) for idx, f in enumerate(tasks)]
                    concurrent.futures.wait(futures)
                    
            stats.print_summary()
    except KeyboardInterrupt:
        console.print("\n[bold red]Terminated by user.[/bold red]")

if __name__ == "__main__":
    main()
