#!/usr/bin/env python3
import os
import sys
import json
import re
import math
import numpy as np
import librosa
import mutagen
from mutagen.flac import FLAC, Picture
from mutagen.mp3 import MP3
from mutagen.id3 import ID3, APIC, USLT, SYLT, TCON, TCOM, TPE1, TPE2, TEXT, TBPM, TKEY, TPOS
from mutagen.mp4 import MP4, MP4Cover, MP4FreeForm, AtomDataType
import requests

# Set environment variable to make librosa/numba fast and quiet
os.environ["NUMBA_CACHE_DIR"] = "/tmp"

# Fallback values
_LOSSLESS_EXTENSIONS = {'flac', 'wav', 'aiff', 'alac'}

def get_audio_duration(path):
    try:
        probe = mutagen.File(path)
        if probe and probe.info:
            return float(probe.info.length)
    except Exception: pass
    try: return float(librosa.get_duration(path=path))
    except Exception: return 0.0

def _librosa_load_safe(path, sr=22050, mono=True, offset=0.0, duration=None):
    import io, soundfile as _sf
    ffmpeg_exe = "ffmpeg"
    cmd = [ffmpeg_exe, "-y", "-hide_banner", "-loglevel", "error"]
    if offset > 0.0: cmd += ["-ss", str(offset)]
    cmd += ["-i", path]
    if duration is not None: cmd += ["-t", str(duration)]
    if mono: cmd += ["-ac", "1"]
    if sr: cmd += ["-ar", str(sr)]
    cmd += ["-f", "wav", "-"]
    try:
        res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, check=True)
        y, file_sr = _sf.read(io.BytesIO(res.stdout), dtype="float32")
        if y.ndim == 2 and mono: y = y.mean(axis=1)
        return y, file_sr
    except Exception:
        import warnings
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            return librosa.load(path, sr=sr, mono=mono, offset=offset, duration=duration)

def detect_lossy_upconvert_detailed(file_path):
    ext = os.path.splitext(file_path)[1].lstrip('.').lower()
    is_lossless = ext in _LOSSLESS_EXTENSIONS
    
    try:
        duration = get_audio_duration(file_path)
        offset = max(0.0, (duration - 30.0) / 2) if duration > 30 else 0.0
        
        # Load audio at 22050Hz (or native for spectrogram)
        y, sr = _librosa_load_safe(file_path, sr=22050, mono=True, offset=offset, duration=30.0)
        if len(y) == 0:
            return {"suspect": False, "reason": "Empty audio content", "spectrogram": []}

        # Calculate spectrogram
        S = np.abs(librosa.stft(y)) ** 2
        freqs = librosa.fft_frequencies(sr=sr)
        
        # Calculate frequency power over time (decibel values)
        power_per_bin = S.mean(axis=1)
        total_power = power_per_bin.sum()
        
        # Convert to dB relative to peak
        S_db = librosa.amplitude_to_db(np.sqrt(S), ref=np.max)
        bin_db_95 = np.percentile(S_db, 95, axis=1) # 95th percentile dB level per bin

        # Downsample frequency values to 128 bins for the web UI visualizer
        chunk_size = len(bin_db_95) // 128 if len(bin_db_95) >= 128 else 1
        spec_data = []
        for i in range(128):
            start = i * chunk_size
            end = start + chunk_size
            chunk_vals = bin_db_95[start:end]
            db_val = float(np.mean(chunk_vals)) if len(chunk_vals) > 0 else -80.0
            freq_val = float(freqs[start]) if start < len(freqs) else float(i * (sr / 256.0))
            spec_data.append({"freq": int(freq_val), "db": round(db_val, 1)})

        # Cutoff check
        active_bins = freqs[bin_db_95 > -65]
        max_active_freq = active_bins[-1] if len(active_bins) > 0 else 0.0
        
        low_mask = freqs < 16000
        low_power = power_per_bin[low_mask].sum()
        ratio = float(low_power / total_power) if total_power > 0 else 1.0

        # Suspect if active frequency is low and ratio is extremely high
        suspect = is_lossless and (max_active_freq < 18500) and (ratio >= 0.999)

        return {
            "suspect": bool(suspect),
            "is_lossless": is_lossless,
            "energy_below_16k": float(ratio),
            "max_active_freq_hz": float(max_active_freq),
            "spectrogram": spec_data
        }
    except Exception as e:
        return {"suspect": False, "error": str(e), "spectrogram": []}

def extract_audio_info(file_path):
    ext = os.path.splitext(file_path)[1].lstrip('.').lower()
    
    meta = {
        "title": os.path.splitext(os.path.basename(file_path))[0],
        "artist": "Unknown",
        "album": "Unknown Album",
        "year": "Unknown",
        "track": "1",
        "genre": "Unknown",
        "composer": "Unknown",
        "duration": 0.0,
        "bpm": 0,
        "key": "Unknown",
        "has_lyrics": False,
        "has_cover": False
    }

    try:
        meta["duration"] = get_audio_duration(file_path)
        audio = mutagen.File(file_path, easy=True)
        if audio:
            if 'title' in audio: meta["title"] = audio['title'][0]
            if 'artist' in audio: meta["artist"] = audio['artist'][0]
            if 'album' in audio: meta["album"] = audio['album'][0]
            if 'date' in audio: meta["year"] = audio['date'][0][:4]
            if 'tracknumber' in audio:
                t = audio['tracknumber'][0]
                meta["track"] = t.split('/')[0] if '/' in t else t
            if 'genre' in audio: meta["genre"] = audio['genre'][0]
            if 'composer' in audio: meta["composer"] = audio['composer'][0]
    except Exception: pass

    # Embedded cover art check
    try:
        if ext == 'flac':
            f_aud = FLAC(file_path)
            meta["has_cover"] = bool(f_aud.pictures)
            meta["has_lyrics"] = bool(f_aud.get("LYRICS") or f_aud.get("UNSYNCEDLYRICS"))
        elif ext == 'mp3':
            m_aud = MP3(file_path, ID3=ID3)
            meta["has_cover"] = bool(m_aud.tags and m_aud.tags.getall('APIC'))
            meta["has_lyrics"] = bool(m_aud.tags and (m_aud.tags.getall('USLT') or m_aud.tags.getall('SYLT')))
        elif ext in ('m4a', 'aac'):
            m4_aud = MP4(file_path)
            if m4_aud.tags:
                meta["has_cover"] = 'covr' in m4_aud.tags
                meta["has_lyrics"] = '©lyr' in m4_aud.tags
    except Exception: pass

    return meta

def analyze_bpm_and_key(file_path):
    try:
        y, sr = _librosa_load_safe(file_path, sr=22050, mono=True)
        tempo, _ = librosa.beat.beat_track(y=y, sr=sr)
        bpm = int(round(float(np.atleast_1d(tempo)[0])))

        ks_major = np.array([6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88])
        ks_minor = np.array([6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17])
        
        chroma = librosa.feature.chroma_cqt(y=y, sr=sr)
        chroma_mean = chroma.mean(axis=1)

        chromatic_notes = ["C", "C#", "D", "Eb", "E", "F", "F#", "G", "Ab", "A", "Bb", "B"]
        best_score = -np.inf
        best_key = "C major"

        for i, note in enumerate(chromatic_notes):
            score_major = np.corrcoef(chroma_mean, np.roll(ks_major, i))[0, 1]
            score_minor = np.corrcoef(chroma_mean, np.roll(ks_minor, i))[0, 1]
            if np.isfinite(score_major) and score_major > best_score:
                best_score = score_major
                best_key = f"{note} major"
            if np.isfinite(score_minor) and score_minor > best_score:
                best_score = score_minor
                best_key = f"{note} minor"

        return {"bpm": bpm, "key": best_key}
    except Exception:
        return {"bpm": 0, "key": "Unknown"}

def wipe_and_replace_artwork(filepath, cover_img_path, mime_type):
    ext = os.path.splitext(filepath)[1].lstrip('.').lower()
    try:
        with open(cover_img_path, "rb") as f:
            img_data = f.read()

        if ext == "flac":
            audio = FLAC(filepath)
            audio.clear_pictures()
            audio.pictures = []
            pic = Picture()
            pic.type = 3
            pic.mime = mime_type
            pic.data = img_data
            audio.add_picture(pic)
            audio.save()
        elif ext == "mp3":
            audio = MP3(filepath, ID3=ID3)
            if audio.tags is None: audio.add_tags()
            audio.tags.delall('APIC')
            audio.tags.add(APIC(encoding=3, mime=mime_type, type=3, desc='Cover', data=img_data))
            audio.save()
        elif ext in ("m4a", "aac"):
            audio = MP4(filepath)
            if audio.tags is None: audio.add_tags()
            if 'covr' in audio.tags: del audio.tags['covr']
            fmt = MP4Cover.FORMAT_PNG if "png" in mime_type else MP4Cover.FORMAT_JPEG
            audio.tags['covr'] = [MP4Cover(img_data, imageformat=fmt)]
            audio.save()
        return True
    except Exception as e:
        sys.stderr.write(f"Wipe artwork failed: {e}\n")
        return False

def apply_metadata_tags(filepath, data, lyrics_text=None, cover_path=None, cover_mime=None):
    ext = os.path.splitext(filepath)[1].lstrip('.').lower()
    
    # 1. Easy Tagging
    try:
        audio = mutagen.File(filepath, easy=True)
        if audio is not None:
            audio["title"] = data.get("title", "")
            audio["artist"] = [data.get("artist", "")]
            audio["album"] = data.get("album", "")
            audio["date"] = str(data.get("year", ""))
            audio["tracknumber"] = str(data.get("track", ""))
            audio["genre"] = data.get("genre", "")
            if data.get("composer") and data["composer"] != "Unknown":
                audio["composer"] = [data["composer"]]
            audio.save()
    except Exception as e:
        sys.stderr.write(f"Easy tag failed: {e}\n")

    # 2. Hardcover replace if provided
    if cover_path and cover_mime:
        wipe_and_replace_artwork(filepath, cover_path, cover_mime)

    # 3. Embedding Lyrics
    if lyrics_text:
        try:
            if ext == "flac":
                audio = FLAC(filepath)
                audio["LYRICS"] = lyrics_text
                audio.save()
            elif ext == "mp3":
                audio = MP3(filepath, ID3=ID3)
                if audio.tags is None: audio.add_tags()
                # USLT plain lyric strip
                uslt_text = re.sub(r'(?m)^(?:\[\d+:\d+(?:\.\d+)?\])+', '', lyrics_text)
                uslt_text = re.sub(r'<\d+:\d+(?:\.\d+)?>', '', uslt_text)
                uslt_text = '\n'.join(ln.strip() for ln in uslt_text.splitlines()).strip()
                audio.tags.add(USLT(encoding=3, lang='eng', desc='', text=uslt_text))
                audio.save()
            elif ext in ("m4a", "aac"):
                audio = MP4(filepath)
                if audio.tags is None: audio.add_tags()
                audio["©lyr"] = [lyrics_text]
                audio.save()
        except Exception as e:
            sys.stderr.write(f"Lyrics embed failed: {e}\n")

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(json.dumps({"error": "Missing parameters"}))
        sys.exit(1)

    cmd = sys.argv[1]
    file_path = sys.argv[2]

    if not os.path.exists(file_path):
        print(json.dumps({"error": f"File does not exist: {file_path}"}))
        sys.exit(1)

    if cmd == "analyze":
        meta = extract_audio_info(file_path)
        spectral = detect_lossy_upconvert_detailed(file_path)
        bpm_key = analyze_bpm_and_key(file_path)
        
        result = {
            "metadata": meta,
            "spectral": {
                "suspect": spectral.get("suspect"),
                "is_lossless": spectral.get("is_lossless"),
                "energy_below_16k": spectral.get("energy_below_16k"),
                "max_active_freq_hz": spectral.get("max_active_freq_hz"),
            },
            "spectrogram": spectral.get("spectrogram", []),
            "bpm": bpm_key["bpm"],
            "key": bpm_key["key"]
        }
        print(json.dumps(result))

    elif cmd == "apply_tags":
        if len(sys.argv) < 4:
            print(json.dumps({"error": "Missing tags json data"}))
            sys.exit(1)
            
        try:
            tags_data = json.loads(sys.argv[3])
            lyrics_text = sys.argv[4] if len(sys.argv) > 4 and sys.argv[4].strip() else None
            cover_path = sys.argv[5] if len(sys.argv) > 5 and sys.argv[5].strip() else None
            cover_mime = sys.argv[6] if len(sys.argv) > 6 and sys.argv[6].strip() else "image/jpeg"
            
            apply_metadata_tags(file_path, tags_data, lyrics_text, cover_path, cover_mime)
            print(json.dumps({"status": "success", "file_path": file_path}))
        except Exception as ex:
            print(json.dumps({"error": f"Exception raised: {ex}"}))
            sys.exit(1)
