import express from "express";
import path from "path";
import fs from "fs";
import { execFile } from "child_process";
import { createServer as createViteServer } from "vite";
import multer from "multer";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

// Initialize directories
const UPLOADS_DIR = path.join(process.cwd(), "uploads");
const OUTPUT_DIR = path.join(process.cwd(), "output");
for (const dir of [UPLOADS_DIR, OUTPUT_DIR]) {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

// Set up Multer for handling file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, UPLOADS_DIR);
  },
  filename: (req, file, cb) => {
    // Keep the original extension but sanitize the name
    const ext = path.extname(file.originalname);
    const base = path.basename(file.originalname, ext).replace(/[^a-zA-Z0-9_-]/g, "_");
    cb(null, `${base}_${Date.now()}${ext}`);
  }
});
const upload = multer({ storage });

app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

// Initialize Gemini SDK lazily to avoid startup crashes if key is missing
let aiClient: GoogleGenAI | null = null;
function getAiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is required but missing");
    }
    aiClient = new GoogleGenAI({ apiKey });
  }
  return aiClient;
}

// Helper to run python script
function runPythonHelper(args: string[]): Promise<any> {
  return new Promise((resolve, reject) => {
    const helperPath = path.join(process.cwd(), "server_helper.py");
    execFile("python3", [helperPath, ...args], { maxBuffer: 1024 * 1024 * 50 }, (error, stdout, stderr) => {
      if (error) {
        reject(new Error(`Python execution error: ${error.message}. Stderr: ${stderr}`));
        return;
      }
      try {
        const parsed = JSON.parse(stdout.trim());
        resolve(parsed);
      } catch (e) {
        reject(new Error(`Failed to parse python output: ${stdout}. Error: ${e}`));
      }
    });
  });
}

// ---------------- API ENDPOINTS ----------------

// 1. Upload File
app.post("/api/upload", upload.single("audio"), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: "No file uploaded" });
  }
  res.json({
    message: "File uploaded successfully",
    originalName: req.file.originalname,
    filename: req.file.filename,
    path: req.file.path,
    size: req.file.size
  });
});

// 2. Analyze File (Metadata, Spectral integrity, BPM & Key)
app.post("/api/analyze", async (req, res) => {
  const { filePath } = req.body;
  if (!filePath || !fs.existsSync(filePath)) {
    return res.status(400).json({ error: "Valid filePath is required" });
  }
  try {
    const result = await runPythonHelper(["analyze", filePath]);
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 3. Proxy Metadata Query to iTunes + MusicBrainz (Node-based parallel calls)
app.get("/api/search-metadata", async (req, res) => {
  const { title, artist } = req.query;
  if (!title) {
    return res.status(400).json({ error: "Title parameter is required" });
  }

  const queryTerm = artist ? `${title} ${artist}` : `${title}`;
  const cleanTitle = String(title).replace(/\(.*?\)|\[.*?\]|\b(official|video|audio|mv)\b/gi, "").trim();

  try {
    // Concurrently fetch from iTunes Search and MusicBrainz Search
    const [itunesRes, mbRes] = await Promise.allSettled([
      fetch(`https://itunes.apple.com/search?term=${encodeURIComponent(queryTerm)}&entity=song&limit=5`)
        .then(r => r.json())
        .catch(() => ({ results: [] })),
      fetch(`https://musicbrainz.org/ws/2/recording/?query=recording:"${encodeURIComponent(cleanTitle)}"${artist ? ` AND artist:"${encodeURIComponent(String(artist))}"` : ""}&fmt=json`, {
        headers: { "User-Agent": "MonsterArchiverWebSuite/18.4 ( hami.kainy.9559@gmail.com )" }
      })
        .then(r => r.json())
        .catch(() => ({ recordings: [] }))
    ]);

    const results: any[] = [];

    // Process iTunes results
    if (itunesRes.status === "fulfilled" && itunesRes.value.results) {
      for (const t of itunesRes.value.results) {
        const rawArt = t.artworkUrl100 || "";
        // Convert to high resolution replacement format
        const hqArt = rawArt.replace(/\d+x\d+bb\.(jpg|png)/i, "100000x100000bb.$1");
        results.push({
          source: "iTunes",
          title: t.trackName || "Unknown",
          artist: t.artistName || "Unknown",
          album: t.collectionName || "Unknown Album",
          year: t.releaseDate ? t.releaseDate.substring(0, 4) : "Unknown",
          track: String(t.trackNumber || "1"),
          genre: t.primaryGenreName || "Unknown",
          composer: t.composerName || "Unknown",
          cover: hqArt,
          release_type: "Album"
        });
      }
    }

    // Process MusicBrainz results
    if (mbRes.status === "fulfilled" && mbRes.value.recordings) {
      for (const rec of mbRes.value.recordings) {
        const release = rec.releases?.[0] || {};
        const releaseMbid = release.id || "";
        const coverUrl = releaseMbid ? `https://coverartarchive.org/release/${releaseMbid}/front` : "";
        
        results.push({
          source: "MusicBrainz",
          title: rec.title || "Unknown",
          artist: rec["artist-credit"]?.[0]?.name || "Unknown",
          album: release.title || "Unknown Album",
          year: release.date ? release.date.substring(0, 4) : "Unknown",
          track: String(release["medium-list"]?.[0]?.["track-list"]?.[0]?.number || "1"),
          genre: rec.tags?.[0]?.name?.toUpperCase() || "Unknown",
          composer: "Unknown",
          cover: coverUrl,
          release_type: release["release-group"]?.type || "Album"
        });
      }
    }

    // Add fallback Deezer lookup if results are sparse
    if (results.length === 0) {
      try {
        const dzRes = await fetch(`https://api.deezer.com/search?q=${encodeURIComponent(queryTerm)}&limit=3`).then(r => r.json());
        if (dzRes && dzRes.data) {
          for (const t of dzRes.data) {
            results.push({
              source: "Deezer",
              title: t.title || "Unknown",
              artist: t.artist?.name || "Unknown",
              album: t.album?.title || "Unknown Album",
              year: "Unknown",
              track: String(t.track_position || "1"),
              genre: "Unknown",
              composer: "Unknown",
              cover: t.album?.cover_xl || "",
              release_type: "Album"
            });
          }
        }
      } catch (dzErr) {}
    }

    res.json(results);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 4. Fetch Synced/Plain Lyrics from LRCLIB
app.get("/api/fetch-lyrics", async (req, res) => {
  const { title, artist } = req.query;
  if (!title) {
    return res.status(400).json({ error: "Title parameter is required" });
  }
  try {
    const q = artist ? `${title} ${artist}` : `${title}`;
    const response = await fetch(`https://lrclib.net/api/search?q=${encodeURIComponent(q)}`);
    if (!response.ok) {
      return res.json([]);
    }
    const data = await response.json();
    const list = data.slice(0, 5).map((t: any) => ({
      source: "LRCLIB",
      id: t.id,
      title: t.name,
      artist: t.artistName,
      synced: t.syncedLyrics || "",
      plain: t.plainLyrics || "",
      duration: t.duration
    })).filter((t: any) => t.synced || t.plain);
    res.json(list);
  } catch (error: any) {
    res.json([]);
  }
});

// 5. Generate & Translate Lyrics using Server-Side Gemini API (Thinking level HIGH)
app.post("/api/generate-lyrics", async (req, res) => {
  const { lyricsText, title, artist, mode } = req.body;
  if (!lyricsText) {
    return res.status(400).json({ error: "Lyrics text is required" });
  }

  try {
    const client = getAiClient();
    const systemPrompt = `You are an expert bilingual lyricist and professional music translator. 
Your goal is to provide a translation that matches the emotional fidelity, poetry, and tone of the original track.
Do not censor, sanitize, or filter any words, profanities, or adult metaphors. Preserving absolute authenticity is a blocking priority.

Instructions based on the mode:
1. "translate_and_merge": For each line in the lyrics, translate it into English. Output the original line, followed immediately by the translated line in full-width parenthesis （like this） on the next line. 
   - Example input:
     [00:12.30]Original Japanese line
   - Example output:
     [00:12.30]Original Japanese line
     [00:12.30]（The poetic English translation）
2. "translate_only": Provide only the translated English lines, matching line-for-line. Preserve all timestamp headers like [mm:ss.xx] exactly as they are in the input.

Do not include any conversational preamble, notes, explanations, or thinking blocks. Output ONLY the completed lyrics text directly.`;

    const userPrompt = `Track Title: "${title || "Unknown"}"\nArtist: "${artist || "Unknown"}"\nRequested Mode: "${mode || "translate_and_merge"}"\n\nLyrics:\n${lyricsText}`;

    // Request the generateContent API using gemini-3.1-pro-preview with HIGH thinking level
    const response = await client.models.generateContent({
      model: "gemini-3.1-pro-preview",
      contents: [
        { role: "system", parts: [{ text: systemPrompt }] },
        { role: "user", parts: [{ text: userPrompt }] }
      ],
      config: {
        thinkingConfig: {
          thinkingBudget: 2048 // Allocates high reasoning budget
        }
      }
    });

    const outputText = response.text || "";
    res.json({ lyrics: outputText });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 6. Apply Tags & Cover (with High Resolution Fallbacks)
app.post("/api/apply-tags", async (req, res) => {
  const { filePath, metadata, lyricsText, coverUrl } = req.body;
  
  if (!filePath || !fs.existsSync(filePath)) {
    return res.status(400).json({ error: "Valid filePath is required" });
  }
  if (!metadata) {
    return res.status(400).json({ error: "Metadata object is required" });
  }

  let tempCoverPath = "";
  let tempCoverMime = "image/jpeg";

  try {
    // If a cover URL is provided, download it using fallback resolutions to resolve "stuck covers"
    if (coverUrl) {
      const urlsToTry = [coverUrl];
      if (coverUrl.includes("mzstatic.com") || coverUrl.includes("apple.com")) {
        const base = coverUrl.replace(/\/\d+x\d+bb\.(jpg|png)/i, "/SIZE_PLACEHOLDERbb.jpg");
        if (base !== coverUrl) {
          urlsToTry.unshift(
            base.replace("SIZE_PLACEHOLDER", "2000x2000"),
            base.replace("SIZE_PLACEHOLDER", "1400x1400"),
            base.replace("SIZE_PLACEHOLDER", "1000x1000")
          );
        }
      }

      for (const url of urlsToTry) {
        try {
          const imgRes = await fetch(url, { headers: { "User-Agent": "Mozilla/5.0" } });
          if (imgRes.ok) {
            const buf = await imgRes.arrayBuffer();
            tempCoverPath = path.join(UPLOADS_DIR, `temp_cover_${Date.now()}.jpg`);
            fs.writeFileSync(tempCoverPath, Buffer.from(buf));
            const ct = imgRes.headers.get("content-type") || "image/jpeg";
            tempCoverMime = ct.split(";")[0].trim().toLowerCase();
            break;
          }
        } catch (e) {
          continue;
        }
      }
    }

    // Call server_helper.py to forcefully strip covers, apply new cover, lyrics, and metadata tags
    const pythonArgs = [
      "apply_tags",
      filePath,
      JSON.stringify(metadata),
      lyricsText || "",
      tempCoverPath,
      tempCoverMime
    ];

    const result = await runPythonHelper(pythonArgs);

    // Clean up temporary cover image
    if (tempCoverPath && fs.existsSync(tempCoverPath)) {
      try { fs.unlinkSync(tempCoverPath); } catch (e) {}
    }

    // Copy the finalized file into the finalized OUTPUT_DIR for easy downloading
    const ext = path.extname(filePath);
    const finalFilename = `${metadata.track.padStart(2, "0")} - ${metadata.title.replace(/[^a-zA-Z0-9 _-]/g, "")}${ext}`;
    const downloadPath = path.join(OUTPUT_DIR, finalFilename);
    fs.copyFileSync(filePath, downloadPath);

    res.json({
      status: "success",
      filename: finalFilename,
      downloadUrl: `/api/download/${encodeURIComponent(finalFilename)}`
    });

  } catch (error: any) {
    if (tempCoverPath && fs.existsSync(tempCoverPath)) {
      try { fs.unlinkSync(tempCoverPath); } catch (e) {}
    }
    res.status(500).json({ error: error.message });
  }
});

// 7. Serves compiled finalized file for download
app.get("/api/download/:filename", (req, res) => {
  const filename = req.params.filename;
  const fullPath = path.join(OUTPUT_DIR, filename);
  if (!fs.existsSync(fullPath)) {
    return res.status(404).send("File not found");
  }
  res.download(fullPath, filename);
});

// Serve static compiled files in production
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*all", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
