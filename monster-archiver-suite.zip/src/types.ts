export interface TrackMetadata {
  title: string;
  artist: string;
  album: string;
  year: string;
  track: string;
  genre: string;
  composer: string;
  duration: number;
  bpm: number;
  key: string;
  has_lyrics: boolean;
  has_cover: boolean;
  cover: string;
}

export interface SpectrogramPoint {
  freq: number;
  db: number;
}

export interface AnalysisResult {
  metadata: TrackMetadata;
  spectral: {
    suspect: boolean;
    is_lossless: boolean;
    energy_below_16k: number;
    max_active_freq_hz: number;
  };
  spectrogram: SpectrogramPoint[];
  bpm: number;
  key: string;
}

export interface LyricsOption {
  source: string;
  id?: number;
  title: string;
  artist: string;
  synced: string;
  plain: string;
  duration?: number;
}
