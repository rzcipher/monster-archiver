import React, { useState } from "react";
import { AlignLeft, Sparkles, Database, Trash2, Check, RefreshCw, Languages, HelpCircle } from "lucide-react";
import { LyricsOption, TrackMetadata } from "../types";
import { motion } from "motion/react";

interface LyricsEditorProps {
  lyricsText: string;
  metadata: TrackMetadata;
  onChange: (text: string) => void;
}

export default function LyricsEditor({
  lyricsText,
  metadata,
  onChange
}: LyricsEditorProps) {
  const [lrclibResults, setLrclibResults] = useState<LyricsOption[]>([]);
  const [searching, setSearching] = useState(false);
  const [translating, setTranslating] = useState(false);
  const [translationMode, setTranslationMode] = useState<"translate_and_merge" | "translate_only">("translate_and_merge");

  const handleFetchDatabase = async () => {
    setSearching(true);
    try {
      const q = `title=${encodeURIComponent(metadata.title)}&artist=${encodeURIComponent(metadata.artist)}`;
      const res = await fetch(`/api/fetch-lyrics?${q}`);
      const data = await res.json();
      setLrclibResults(data);
    } catch (e) {
      console.error(e);
    } finally {
      setSearching(false);
    }
  };

  const handleApplyLyrics = (lyric: LyricsOption) => {
    const text = lyric.synced || lyric.plain;
    onChange(text);
  };

  const handleGeminiTranslate = async () => {
    if (!lyricsText.trim()) return;
    setTranslating(true);
    try {
      const res = await fetch("/api/generate-lyrics", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          lyricsText,
          title: metadata.title,
          artist: metadata.artist,
          mode: translationMode
        })
      });
      const data = await res.json();
      if (data.lyrics) {
        onChange(data.lyrics);
      } else if (data.error) {
        alert(`Gemini Translation Error: ${data.error}`);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setTranslating(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      
      {/* LRC LYRICS TEXTAREA */}
      <div className="lg:col-span-2 bg-[#0f1117] rounded-xl border border-slate-800 p-6 shadow-2xl flex flex-col ring-1 ring-white/5">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-4 border-b border-slate-800/60 pb-3">
          <h3 className="text-white font-medium text-lg flex items-center gap-2">
            <AlignLeft className="w-5 h-5 text-indigo-400" />
            LRC Synced / Plain Lyrics Editor
          </h3>
          <div className="flex items-center gap-2">
            <button 
              onClick={() => onChange("")}
              className="px-2.5 py-1.5 bg-[#0b0e14]/80 border border-slate-800 hover:bg-slate-800 text-slate-300 rounded-lg text-xs flex items-center gap-1 transition-colors cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5 text-rose-500" />
              Wipe
            </button>
          </div>
        </div>

        <textarea
          value={lyricsText}
          onChange={(e) => onChange(e.target.value)}
          placeholder="[00:10.00]Line 1
[00:15.50]Line 2..."
          className="w-full h-80 bg-[#0b0e14]/60 border border-slate-800 rounded-lg p-4 text-white text-sm font-mono focus:outline-none focus:border-indigo-500 transition-colors custom-scrollbar resize-none flex-1 leading-relaxed"
        />
      </div>

      {/* GEMINI INTELLIGENCE & DB SEARCH SIDEBAR */}
      <div className="space-y-6">
        
        {/* Gemini Translating Engine Card */}
        <div className="bg-[#0f1117] rounded-xl border border-slate-800 p-6 shadow-2xl relative overflow-hidden ring-1 ring-white/5">
          <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-500/5 rounded-full blur-2xl pointer-events-none" />
          
          <h4 className="text-white font-semibold text-sm uppercase tracking-wider mb-4 flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-indigo-400" />
            Gemini Translator
          </h4>

          <p className="text-slate-400 text-xs mb-4">
            Powered by <span className="text-indigo-400 font-semibold font-mono">gemini-3.1-pro</span> with High Thinking enabled. Translates text line-for-line, retaining timed synchronization anchors intact.
          </p>

          <div className="mb-4">
            <label className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-1.5 block">Translation Mode</label>
            <select
              value={translationMode}
              onChange={(e) => setTranslationMode(e.target.value as any)}
              className="w-full bg-[#0b0e14] border border-slate-800 rounded-lg py-2 px-3 text-white text-xs focus:outline-none focus:border-indigo-500 transition-colors cursor-pointer"
            >
              <option value="translate_and_merge">Bilingual （Side-by-Side）</option>
              <option value="translate_only">Replace with English Translation Only</option>
            </select>
          </div>

          <button
            onClick={handleGeminiTranslate}
            disabled={translating || !lyricsText.trim()}
            className="w-full py-3 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 disabled:from-slate-800 disabled:to-slate-800 disabled:text-slate-600 text-white rounded-lg text-sm font-semibold transition-all shadow-lg flex items-center justify-center gap-2 cursor-pointer border-0"
          >
            {translating ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin text-indigo-200" />
                Thinking & Translating...
              </>
            ) : (
              <>
                <Languages className="w-4 h-4 text-indigo-200" />
                Apply Gemini Translation
              </>
            )}
          </button>
        </div>

        {/* Synced LRC Lyrics Database imports */}
        <div className="bg-[#0f1117] rounded-xl border border-slate-800 p-6 shadow-2xl ring-1 ring-white/5">
          <h4 className="text-white font-semibold text-sm uppercase tracking-wider mb-3 flex items-center gap-1.5">
            <Database className="w-4 h-4 text-emerald-400" />
            LRCLIB Synced DB
          </h4>

          <button
            onClick={handleFetchDatabase}
            disabled={searching}
            className="w-full py-2 bg-[#0b0e14]/80 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 text-white rounded-lg text-xs font-semibold transition-all flex items-center justify-center gap-1.5 cursor-pointer mb-3"
          >
            {searching ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Database className="w-3.5 h-3.5" />}
            Scan Cloud Database
          </button>

          <div className="overflow-y-auto max-h-[160px] space-y-2 pr-1 custom-scrollbar">
            {lrclibResults.map((l, idx) => (
              <div 
                key={idx}
                className="bg-[#0b0e14]/60 border border-slate-800/60 hover:border-indigo-500/50 rounded-lg p-2.5 transition-all text-left flex gap-2 items-center cursor-pointer group"
                onClick={() => handleApplyLyrics(l)}
              >
                <div className="min-w-0 flex-1">
                  <h5 className="text-white text-xs font-semibold truncate leading-tight">{l.title}</h5>
                  <p className="text-slate-400 text-[10px] truncate">{l.artist} • <span className="text-emerald-400 font-medium">{l.synced ? "Synced LRC" : "Plain Lyrics"}</span></p>
                </div>
              </div>
            ))}
            {lrclibResults.length === 0 && !searching && (
              <div className="text-center py-6 text-slate-600 text-xs">
                Scan the cloud to pull timing blocks from LRCLIB community database.
              </div>
            )}
          </div>
        </div>

      </div>
    </div>
  );
}
