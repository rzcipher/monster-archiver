import React, { useState } from "react";
import { Music, Disc, Calendar, Hash, Tag, User, Search, RefreshCw, Layers, Check } from "lucide-react";
import { TrackMetadata, LyricsOption } from "../types";
import { motion, AnimatePresence } from "motion/react";

interface MetadataPanelProps {
  metadata: TrackMetadata;
  onChange: (updated: TrackMetadata) => void;
  onApplyPreset: (meta: any) => void;
}

export default function MetadataPanel({
  metadata,
  onChange,
  onApplyPreset
}: MetadataPanelProps) {
  const [searchTitle, setSearchTitle] = useState(metadata.title || "");
  const [searchArtist, setSearchArtist] = useState(metadata.artist || "");
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [searching, setSearching] = useState(false);
  const [customCoverUrl, setCustomCoverUrl] = useState(metadata.cover || "");

  const handleFieldChange = (key: keyof TrackMetadata, val: any) => {
    onChange({
      ...metadata,
      [key]: val
    });
  };

  const handleSearch = async () => {
    if (!searchTitle.trim()) return;
    setSearching(true);
    try {
      const q = `title=${encodeURIComponent(searchTitle)}&artist=${encodeURIComponent(searchArtist)}`;
      const res = await fetch(`/api/search-metadata?${q}`);
      const data = await res.json();
      setSearchResults(data);
    } catch (e) {
      console.error(e);
    } finally {
      setSearching(false);
    }
  };

  const handleApplyPreset = (preset: any) => {
    onApplyPreset(preset);
    if (preset.cover) {
      setCustomCoverUrl(preset.cover);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      
      {/* 1. EDITABLE TAGS FORM */}
      <div className="lg:col-span-2 bg-[#0f1117] rounded-xl border border-slate-800 p-6 shadow-2xl ring-1 ring-white/5">
        <h3 className="text-white font-medium text-lg mb-5 flex items-center gap-2 border-b border-slate-800/60 pb-3">
          <Tag className="w-5 h-5 text-indigo-400" />
          Track Metadata Tags
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          
          {/* Title */}
          <div>
            <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5 block">Title</label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500">
                <Music className="w-4 h-4" />
              </span>
              <input 
                type="text" 
                value={metadata.title} 
                onChange={(e) => handleFieldChange("title", e.target.value)}
                className="w-full bg-[#0b0e14]/60 border border-slate-800 rounded-lg py-2.5 pl-10 pr-4 text-white text-sm focus:outline-none focus:border-indigo-500 transition-colors"
              />
            </div>
          </div>

          {/* Artist */}
          <div>
            <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5 block">Artist</label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500">
                <User className="w-4 h-4" />
              </span>
              <input 
                type="text" 
                value={metadata.artist} 
                onChange={(e) => handleFieldChange("artist", e.target.value)}
                className="w-full bg-[#0b0e14]/60 border border-slate-800 rounded-lg py-2.5 pl-10 pr-4 text-white text-sm focus:outline-none focus:border-indigo-500 transition-colors"
              />
            </div>
          </div>

          {/* Album */}
          <div>
            <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5 block">Album</label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500">
                <Disc className="w-4 h-4" />
              </span>
              <input 
                type="text" 
                value={metadata.album} 
                onChange={(e) => handleFieldChange("album", e.target.value)}
                className="w-full bg-[#0b0e14]/60 border border-slate-800 rounded-lg py-2.5 pl-10 pr-4 text-white text-sm focus:outline-none focus:border-indigo-500 transition-colors"
              />
            </div>
          </div>

          {/* Year */}
          <div>
            <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5 block">Year</label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500">
                <Calendar className="w-4 h-4" />
              </span>
              <input 
                type="text" 
                value={metadata.year} 
                onChange={(e) => handleFieldChange("year", e.target.value)}
                className="w-full bg-[#0b0e14]/60 border border-slate-800 rounded-lg py-2.5 pl-10 pr-4 text-white text-sm focus:outline-none focus:border-indigo-500 transition-colors"
              />
            </div>
          </div>

          {/* Track Number */}
          <div>
            <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5 block">Track Number</label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500">
                <Hash className="w-4 h-4" />
              </span>
              <input 
                type="text" 
                value={metadata.track} 
                onChange={(e) => handleFieldChange("track", e.target.value)}
                className="w-full bg-[#0b0e14]/60 border border-slate-800 rounded-lg py-2.5 pl-10 pr-4 text-white text-sm focus:outline-none focus:border-indigo-500 transition-colors"
              />
            </div>
          </div>

          {/* Genre */}
          <div>
            <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5 block">Genre</label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500">
                <Layers className="w-4 h-4" />
              </span>
              <input 
                type="text" 
                value={metadata.genre} 
                onChange={(e) => handleFieldChange("genre", e.target.value)}
                className="w-full bg-[#0b0e14]/60 border border-slate-800 rounded-lg py-2.5 pl-10 pr-4 text-white text-sm focus:outline-none focus:border-indigo-500 transition-colors"
              />
            </div>
          </div>

          {/* Composer */}
          <div>
            <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5 block">Composer</label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500">
                <User className="w-4 h-4" />
              </span>
              <input 
                type="text" 
                value={metadata.composer} 
                onChange={(e) => handleFieldChange("composer", e.target.value)}
                className="w-full bg-[#0b0e14]/60 border border-slate-800 rounded-lg py-2.5 pl-10 pr-4 text-white text-sm focus:outline-none focus:border-indigo-500 transition-colors"
              />
            </div>
          </div>

          {/* BPM & Key */}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5 block">BPM</label>
              <input 
                type="number" 
                value={metadata.bpm || ""} 
                onChange={(e) => handleFieldChange("bpm", parseInt(e.target.value) || 0)}
                className="w-full bg-[#0b0e14]/60 border border-slate-800 rounded-lg py-2.5 px-4 text-white text-sm focus:outline-none focus:border-indigo-500 transition-colors"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5 block">Key</label>
              <input 
                type="text" 
                value={metadata.key || ""} 
                onChange={(e) => handleFieldChange("key", e.target.value)}
                className="w-full bg-[#0b0e14]/60 border border-slate-800 rounded-lg py-2.5 px-4 text-white text-sm focus:outline-none focus:border-indigo-500 transition-colors"
              />
            </div>
          </div>

        </div>

        {/* Cover Art URL Input */}
        <div className="mt-5">
          <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5 block">Album Artwork URL</label>
          <input 
            type="text" 
            value={metadata.cover || ""} 
            onChange={(e) => handleFieldChange("cover", e.target.value)}
            placeholder="Embed high-quality online jpg or png artwork URL"
            className="w-full bg-[#0b0e14]/60 border border-slate-800 rounded-lg py-2.5 px-4 text-white text-sm focus:outline-none focus:border-indigo-500 transition-colors font-mono text-xs"
          />
        </div>
      </div>

      {/* 2. ARTWORK PREVIEW & ONLINE SEARCH SIDEBAR */}
      <div className="bg-[#0f1117] rounded-xl border border-slate-800 p-6 shadow-2xl flex flex-col h-full justify-between ring-1 ring-white/5">
        
        {/* Cover Art Display with Stuck Resolution Safeguards */}
        <div className="mb-6">
          <h4 className="text-white font-medium text-sm uppercase tracking-wider mb-3 block">Artwork Preview</h4>
          <div className="w-full aspect-square bg-[#0b0e14]/80 rounded-lg overflow-hidden border border-slate-800 relative group flex items-center justify-center">
            {metadata.cover ? (
              <img 
                src={metadata.cover} 
                alt="Album Cover"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-transform group-hover:scale-105 duration-300"
              />
            ) : (
              <div className="flex flex-col items-center justify-center text-slate-600">
                <Disc className="w-16 h-16 animate-spin-slow mb-2 text-indigo-500/40" />
                <p className="text-xs font-medium uppercase tracking-wider text-slate-500">No Cover Embedded</p>
              </div>
            )}
          </div>
          {metadata.cover && (
            <div className="mt-2.5 flex items-center justify-between">
              <span className="text-[10px] text-emerald-400 font-medium">Resolving Fallbacks Active</span>
              <button 
                onClick={() => handleFieldChange("cover", metadata.cover.replace(/100000x100000|1400x1400|2000x2000/g, "1400x1400"))}
                className="text-[10px] text-indigo-400 hover:underline font-mono bg-transparent border-0 cursor-pointer"
              >
                Forces 1400px Master
              </button>
            </div>
          )}
        </div>

        {/* Dynamic Global Metadata Lookup Widget */}
        <div className="border-t border-slate-800/60 pt-4 flex-1 flex flex-col">
          <h4 className="text-white font-medium text-sm uppercase tracking-wider mb-3 block flex items-center gap-1.5">
            <Search className="w-4 h-4 text-indigo-400" />
            Global API Finder
          </h4>

          <div className="flex gap-2 mb-3">
            <input 
              type="text" 
              placeholder="Song..."
              value={searchTitle}
              onChange={(e) => setSearchTitle(e.target.value)}
              className="w-1/2 bg-[#0b0e14] border border-slate-800 rounded-lg py-1.5 px-3 text-white text-xs focus:outline-none focus:border-indigo-500"
            />
            <input 
              type="text" 
              placeholder="Artist..."
              value={searchArtist}
              onChange={(e) => setSearchArtist(e.target.value)}
              className="w-1/2 bg-[#0b0e14] border border-slate-800 rounded-lg py-1.5 px-3 text-white text-xs focus:outline-none focus:border-indigo-500"
            />
            <button 
              onClick={handleSearch}
              disabled={searching}
              className="p-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg transition-colors flex items-center justify-center shrink-0 cursor-pointer"
            >
              {searching ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
            </button>
          </div>

          <div className="overflow-y-auto max-h-[160px] space-y-2 pr-1 custom-scrollbar flex-1">
            {searchResults.map((r, idx) => (
              <div 
                key={idx}
                className="bg-[#0b0e14]/60 border border-slate-800 hover:border-indigo-500/50 rounded-lg p-2.5 transition-all text-left flex gap-2.5 items-center group cursor-pointer"
                onClick={() => handleApplyPreset(r)}
              >
                {r.cover ? (
                  <img src={r.cover} alt="" referrerPolicy="no-referrer" className="w-9 h-9 rounded object-cover border border-slate-800/50" />
                ) : (
                  <div className="w-9 h-9 rounded bg-[#0b0e14] flex items-center justify-center text-slate-500"><Music className="w-4 h-4" /></div>
                )}
                <div className="min-w-0 flex-1">
                  <h5 className="text-white text-xs font-semibold truncate leading-tight">{r.title}</h5>
                  <p className="text-slate-400 text-[10px] truncate">{r.artist} • <span className="text-indigo-400 font-medium font-mono">{r.source}</span></p>
                </div>
              </div>
            ))}
            {searchResults.length === 0 && !searching && (
              <div className="text-center py-6 text-slate-600 text-xs">
                Enter parameters and hit search to find official release tags.
              </div>
            )}
          </div>
        </div>

      </div>
    </div>
  );
}
