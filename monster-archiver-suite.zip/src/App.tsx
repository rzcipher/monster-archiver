import React, { useState, useEffect } from "react";
import { 
  UploadCloud, 
  Disc, 
  Settings, 
  Activity, 
  FileAudio, 
  CheckCircle, 
  ChevronRight, 
  ArrowDownToLine, 
  Tag, 
  AlignLeft, 
  Volume2, 
  AlertCircle, 
  Sparkles,
  RefreshCw,
  FileCheck
} from "lucide-react";
import { TrackMetadata, AnalysisResult } from "./types";
import SpectrogramView from "./components/SpectrogramView";
import MetadataPanel from "./components/MetadataPanel";
import LyricsEditor from "./components/LyricsEditor";
import { motion, AnimatePresence } from "motion/react";

export default function App() {
  const [currentTime, setCurrentTime] = useState("");
  const [uploadedFile, setUploadedFile] = useState<any>(null);
  const [uploading, setUploading] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [compiling, setCompiling] = useState(false);
  
  const [activeTab, setActiveTab] = useState<"spectral" | "tags" | "lyrics">("spectral");
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [metadata, setMetadata] = useState<TrackMetadata | null>(null);
  const [lyricsText, setLyricsText] = useState("");
  
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);
  const [downloadFilename, setDownloadFilename] = useState<string | null>(null);

  // Update clock every second
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(now.toISOString().replace("T", " ").substring(0, 19) + " UTC");
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Handle drag-over events
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  // Handle drop file event
  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      await uploadFile(files[0]);
    }
  };

  // Handle manual input file selection
  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      await uploadFile(files[0]);
    }
  };

  // Upload file via API
  const uploadFile = async (file: File) => {
    // Validate file extensions
    const ext = file.name.substring(file.name.lastIndexOf(".")).toLowerCase();
    const allowed = [".mp3", ".flac", ".m4a", ".aac", ".wav"];
    if (!allowed.includes(ext)) {
      alert("Unsupported format. Please upload MP3, FLAC, M4A, AAC, or WAV files.");
      return;
    }

    setUploading(true);
    setAnalysisResult(null);
    setMetadata(null);
    setLyricsText("");
    setDownloadUrl(null);

    const formData = new FormData();
    formData.append("audio", file);

    try {
      const res = await fetch("/api/upload", {
        method: "POST",
        body: formData
      });
      const data = await res.json();
      if (data.path) {
        setUploadedFile(data);
        await analyzeFile(data.path);
      }
    } catch (e) {
      console.error("Upload failed", e);
    } finally {
      setUploading(false);
    }
  };

  // Analyze uploaded audio
  const analyzeFile = async (filePath: string) => {
    setAnalyzing(true);
    try {
      const res = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ filePath })
      });
      const data: AnalysisResult = await res.json();
      setAnalysisResult(data);
      setMetadata(data.metadata);
      // Retrieve empty lyrics placeholder
      setLyricsText("");
    } catch (e) {
      console.error("Analysis failed", e);
    } finally {
      setAnalyzing(false);
    }
  };

  const handleApplyPreset = (preset: any) => {
    if (!metadata) return;
    setMetadata({
      ...metadata,
      title: preset.title || metadata.title,
      artist: preset.artist || metadata.artist,
      album: preset.album || metadata.album,
      year: preset.year || metadata.year,
      track: preset.track || metadata.track,
      genre: preset.genre || metadata.genre,
      composer: preset.composer || metadata.composer,
      cover: preset.cover || metadata.cover
    });
  };

  // Tag override and save
  const handleCompile = async () => {
    if (!uploadedFile || !metadata) return;
    setCompiling(true);
    try {
      const res = await fetch("/api/apply-tags", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          filePath: uploadedFile.path,
          metadata,
          lyricsText,
          coverUrl: metadata.cover
        })
      });
      const data = await res.json();
      if (data.status === "success") {
        setDownloadUrl(data.downloadUrl);
        setDownloadFilename(data.filename);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setCompiling(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0b0e14] font-sans text-slate-300 relative overflow-x-hidden selection:bg-indigo-500/25 selection:text-indigo-200">
      
      {/* Dynamic Cosmic Background Gradients */}
      <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-indigo-500/5 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-violet-500/5 rounded-full blur-[120px] pointer-events-none" />

      {/* HEADER BAR */}
      <header className="border-b border-slate-800/80 bg-[#0f1117]/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-gradient-to-tr from-indigo-500 to-violet-600 rounded-lg shadow-lg shadow-indigo-500/10">
              <Disc className="w-5 h-5 text-white animate-spin-slow" />
            </div>
            <div>
              <h1 className="text-white font-bold text-base tracking-tight">Monster Archiver</h1>
              <p className="text-[10px] text-slate-500 font-mono tracking-wider uppercase font-semibold">Nexus Web Suite v18.4</p>
            </div>
          </div>

          <div className="flex items-center gap-6">
            {/* UTC Real-Time Clock */}
            <div className="hidden sm:flex flex-col items-end">
              <span className="text-[10px] text-slate-500 font-semibold uppercase tracking-wider font-mono">System Time</span>
              <span className="text-slate-300 text-xs font-mono font-medium">{currentTime || "Loading..."}</span>
            </div>
          </div>
        </div>
      </header>

      {/* MAIN CONTAINER */}
      <main className="max-w-7xl mx-auto px-6 py-8">
        
        {/* DRAG AND DROP ZONE */}
        <div 
          onDragOver={handleDragOver}
          onDrop={handleDrop}
          className="w-full bg-[#0f1117] rounded-xl border-2 border-dashed border-slate-800 hover:border-indigo-500/40 p-10 text-center transition-all shadow-2xl relative overflow-hidden group mb-8 ring-1 ring-white/5"
        >
          <div className="absolute top-0 right-0 w-48 h-48 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none group-hover:bg-indigo-500/10 transition-colors" />
          
          <input 
            type="file" 
            id="fileInput" 
            accept=".mp3,.flac,.m4a,.aac,.wav" 
            onChange={handleFileSelect} 
            className="hidden" 
          />

          <label htmlFor="fileInput" className="cursor-pointer block">
            <div className="w-16 h-16 bg-[#0b0e14] border border-slate-800 rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:scale-105 transition-transform duration-300 text-slate-400 group-hover:text-indigo-400 group-hover:border-indigo-500/20 shadow-lg">
              {uploading ? (
                <RefreshCw className="w-8 h-8 animate-spin text-indigo-400" />
              ) : (
                <UploadCloud className="w-8 h-8" />
              )}
            </div>
            
            <h2 className="text-white font-semibold text-lg leading-snug">
              {uploading ? "Uploading Audio Track..." : "Drag & Drop Audio File Here"}
            </h2>
            <p className="text-slate-500 text-xs mt-1.5 max-w-sm mx-auto leading-relaxed">
              Supports FLAC, MP3, M4A, AAC, and WAV audio containers. Maximum upload size up to 100MB.
            </p>
          </label>
        </div>

        {/* WORKSPACE AREA (Triggered when uploaded) */}
        <AnimatePresence mode="wait">
          {uploadedFile && (
            <motion.div
              key="workspace"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.3 }}
              className="space-y-8"
            >
              {/* CURRENT FILE HEADER SUMMARY */}
              <div className="bg-[#0f1117] rounded-xl border border-slate-800 p-5 shadow-xl flex flex-wrap items-center justify-between gap-4 ring-1 ring-white/5">
                <div className="flex items-center gap-3.5">
                  <div className="p-3 bg-indigo-950/30 border border-indigo-800/20 rounded-lg text-indigo-400">
                    <FileAudio className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-white font-semibold text-base truncate max-w-md">{uploadedFile.originalName}</h3>
                    <p className="text-slate-400 text-xs font-mono">Size: {(uploadedFile.size / (1024 * 1024)).toFixed(1)} MB • Status: <span className="text-emerald-400 font-medium font-sans">Uploaded</span></p>
                  </div>
                </div>

                {/* Compile Actions */}
                <div className="flex items-center gap-3">
                  {downloadUrl ? (
                    <a 
                      href={downloadUrl}
                      download={downloadFilename || "compiled_track"}
                      className="px-5 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white rounded-lg text-sm font-semibold transition-all shadow-lg flex items-center gap-2 cursor-pointer border-0"
                    >
                      <ArrowDownToLine className="w-4 h-4" />
                      Download finalized audio
                    </a>
                  ) : (
                    <button 
                      onClick={handleCompile}
                      disabled={compiling || !metadata}
                      className="px-5 py-2.5 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 disabled:from-slate-800 disabled:to-slate-800 disabled:text-slate-600 text-white rounded-lg text-sm font-semibold transition-all shadow-lg flex items-center gap-2 cursor-pointer border-0"
                    >
                      {compiling ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin" />
                          Tagging & Compiling...
                        </>
                      ) : (
                        <>
                          <FileCheck className="w-4 h-4" />
                          Compile & Download
                        </>
                      )}
                    </button>
                  )}
                </div>
              </div>

              {/* TABS SELECTOR */}
              <div className="flex border-b border-slate-800 gap-1.5 overflow-x-auto pb-px">
                {[
                  { id: "spectral", label: "Lossless Scan", icon: Activity },
                  { id: "tags", label: "Metadata Tags", icon: Tag },
                  { id: "lyrics", label: "AI Lyrics Studio", icon: AlignLeft }
                ].map((t) => {
                  const Icon = t.icon;
                  const active = activeTab === t.id;
                  return (
                    <button
                      key={t.id}
                      onClick={() => setActiveTab(t.id as any)}
                      className={`px-5 py-3 border-b-2 flex items-center gap-2 text-sm font-medium transition-all cursor-pointer bg-transparent outline-none ${
                        active 
                          ? "border-indigo-500 text-white font-semibold" 
                          : "border-transparent text-slate-500 hover:text-slate-300"
                      }`}
                    >
                      <Icon className={`w-4 h-4 ${active ? "text-indigo-400" : "text-slate-500"}`} />
                      {t.label}
                    </button>
                  );
                })}
              </div>

              {/* ACTIVE TAB CONTENT */}
              <div className="min-h-[400px]">
                {analyzing ? (
                  <div className="flex flex-col items-center justify-center py-20 bg-[#0f1117] rounded-xl border border-slate-800 ring-1 ring-white/5 shadow-2xl">
                    <RefreshCw className="w-10 h-10 text-indigo-400 animate-spin mb-4" />
                    <p className="text-slate-400 text-sm font-medium animate-pulse">Running advanced Python spectrogram diagnostic & BPM track analyzer...</p>
                  </div>
                ) : (
                  <>
                    {activeTab === "spectral" && analysisResult && (
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="space-y-6"
                      >
                        <SpectrogramView 
                          spectrogram={analysisResult.spectrogram}
                          suspect={analysisResult.spectral.suspect}
                          isLossless={analysisResult.spectral.is_lossless}
                          maxActiveFreq={analysisResult.spectral.max_active_freq_hz}
                          energyBelow16k={analysisResult.spectral.energy_below_16k}
                        />

                        {/* Extra analysis items */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          
                          {/* File specs */}
                          <div className="bg-[#0f1117] rounded-xl border border-slate-800 p-5 shadow-2xl ring-1 ring-white/5">
                            <h4 className="text-white font-medium text-sm mb-3.5 flex items-center gap-1.5 uppercase tracking-wider text-slate-400">
                              <Volume2 className="w-4 h-4 text-indigo-400" />
                              Audio Features Output
                            </h4>
                            <div className="grid grid-cols-2 gap-4">
                              <div className="bg-[#0b0e14]/60 rounded-lg p-3 border border-slate-800/60">
                                <span className="text-[10px] text-slate-500 font-semibold block uppercase tracking-wider">Tempo</span>
                                <span className="text-white font-bold text-lg font-mono">{analysisResult.bpm || "Calculating..."} BPM</span>
                              </div>
                              <div className="bg-[#0b0e14]/60 rounded-lg p-3 border border-slate-800/60">
                                <span className="text-[10px] text-slate-500 font-semibold block uppercase tracking-wider">Musical Key</span>
                                <span className="text-white font-bold text-lg font-mono">{analysisResult.key || "Calculating..."}</span>
                              </div>
                            </div>
                          </div>

                          {/* Quick checklist */}
                          <div className="bg-[#0f1117] rounded-xl border border-slate-800 p-5 shadow-2xl ring-1 ring-white/5 flex flex-col justify-between">
                            <h4 className="text-white font-medium text-sm mb-3 flex items-center gap-1.5 uppercase tracking-wider text-slate-400">
                              <CheckCircle className="w-4 h-4 text-emerald-400" />
                              Pre-Check Checklist
                            </h4>
                            <div className="space-y-2 text-xs">
                              <div className="flex items-center justify-between p-2.5 bg-[#0b0e14]/40 rounded-lg border border-slate-800/60">
                                <span className="text-slate-400">Embedded Lyrics Tag</span>
                                <span className={`font-semibold ${analysisResult.metadata.has_lyrics ? "text-emerald-400" : "text-amber-400"}`}>
                                  {analysisResult.metadata.has_lyrics ? "Wiped & Synced" : "None detected"}
                                </span>
                              </div>
                              <div className="flex items-center justify-between p-2.5 bg-[#0b0e14]/40 rounded-lg border border-slate-800/60">
                                <span className="text-slate-400">Embedded Cover Art</span>
                                <span className={`font-semibold ${analysisResult.metadata.has_cover ? "text-emerald-400" : "text-amber-400"}`}>
                                  {analysisResult.metadata.has_cover ? "Embedded" : "None detected"}
                                </span>
                              </div>
                            </div>
                          </div>

                        </div>
                      </motion.div>
                    )}

                    {activeTab === "tags" && metadata && (
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                      >
                        <MetadataPanel 
                          metadata={metadata}
                          onChange={(updated) => setMetadata(updated)}
                          onApplyPreset={handleApplyPreset}
                        />
                      </motion.div>
                    )}

                    {activeTab === "lyrics" && metadata && (
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                      >
                        <LyricsEditor 
                          lyricsText={lyricsText}
                          metadata={metadata}
                          onChange={(text) => setLyricsText(text)}
                        />
                      </motion.div>
                    )}
                  </>
                )}
              </div>
            </motion.div>
          )}
          
          {!uploadedFile && !uploading && (
            <motion.div
              key="welcome"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex flex-col items-center justify-center py-20 text-center"
            >
              <div className="p-4 bg-[#0f1117] border border-slate-800 rounded-xl text-indigo-400 mb-4 animate-bounce ring-1 ring-white/5">
                <Disc className="w-12 h-12" />
              </div>
              <h3 className="text-white font-semibold text-lg">No active track in workspace</h3>
              <p className="text-slate-500 text-sm max-w-sm mt-1.5 leading-relaxed">
                Drag and drop your audio files above to initialize the tagging, spectrogram analyzer, and lyric compiler dashboard.
              </p>
            </motion.div>
          )}
        </AnimatePresence>

      </main>

      {/* FOOTER BAR */}
      <footer className="border-t border-slate-800/80 py-6 mt-16 bg-[#0f1117]/40">
        <div className="max-w-7xl mx-auto px-6 text-center text-xs text-slate-600 font-mono">
          Monster Archiver Suite • Built with React & Node full-stack microservices • Licensed under Apache 2.0
        </div>
      </footer>

    </div>
  );
}
