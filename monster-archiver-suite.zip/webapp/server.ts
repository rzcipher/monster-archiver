import express from "express";
import path from "path";
import { execFile } from "child_process";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";

import { PORT, HOST } from "./lib/serverConfig";
import { ensurePythonDeps } from "./lib/pythonBridge";

import uploadRoute from "./routes/upload";
import analyzeRoute from "./routes/analyze";
import metadataRoute from "./routes/metadata";
import lyricsRoute from "./routes/lyrics";
import tagsRoute from "./routes/tags";
import libraryRoute from "./routes/library";
import settingsRoute from "./routes/settings";
import activityRoute from "./routes/activity";
import captionsRoute from "./routes/captions";

dotenv.config();

const app = express();

app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

app.use(uploadRoute);
app.use(analyzeRoute);
app.use(metadataRoute);
app.use(lyricsRoute);
app.use(tagsRoute);
app.use(libraryRoute);
app.use(settingsRoute);
app.use(activityRoute);
app.use(captionsRoute);

app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error("Express Error:", err);
  res.status(err.status || 500).json({ error: err.message || "Internal Server Error" });
});

function openBrowser(url: string) {
  // execFile reports spawn failures (e.g. no xdg-open on a headless box) via an
  // async "error" event, not a thrown exception — an unhandled one would crash
  // the server, so it's caught here rather than with try/catch.
  const child =
    process.platform === "win32"
      ? execFile("cmd", ["/c", "start", "", url])
      : execFile(process.platform === "darwin" ? "open" : "xdg-open", [url]);
  child.on("error", () => {
    // Non-fatal — just means the user opens the URL themselves.
  });
}

// Serve static compiled files in production
async function startServer() {
  ensurePythonDeps();

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*all", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, HOST, () => {
    const url = `http://${HOST}:${PORT}`;
    console.log(`\nMonster Archiver Suite running at ${url}\n`);
    if (!process.env.NO_BROWSER) {
      openBrowser(url);
    }
  });
}

startServer();
