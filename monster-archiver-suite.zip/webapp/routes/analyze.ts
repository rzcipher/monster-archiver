import { Router } from "express";
import fs from "fs";
import { runPythonHelper } from "../lib/pythonBridge";

const router = Router();

// Analyze File (Metadata, Spectral integrity, BPM & Key)
router.post("/api/analyze", async (req, res) => {
  const { filePath } = req.body;
  if (!filePath || !fs.existsSync(filePath)) {
    return res.status(400).json({ error: "Valid filePath is required" });
  }
  try {
    const result = await runPythonHelper(["analyze", filePath]);
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

export default router;
