const fs = require('fs');
let file = './monster-archiver-suite/webapp/src/components/MetadataPanel.tsx';
let content = fs.readFileSync(file, 'utf8');

content = content.replace(
  /interface MetadataPanelProps \{\n  metadata: TrackMetadata;\n  onChange: \(metadata: TrackMetadata\) => void;\n  fileName: string;\n\}/,
  `interface MetadataPanelProps {
  metadata: TrackMetadata;
  onChange: (metadata: TrackMetadata) => void;
  onApplyPreset?: (preset: SearchPreset) => void;
}`
);

content = content.replace(
  /export default function MetadataPanel\(\{ metadata, onChange, fileName \}: MetadataPanelProps\) \{/,
  `export default function MetadataPanel({ metadata, onChange, onApplyPreset }: MetadataPanelProps) {`
);

fs.writeFileSync(file, content);
