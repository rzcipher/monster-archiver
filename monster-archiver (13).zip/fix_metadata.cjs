const fs = require('fs');
let file = './monster-archiver-suite/webapp/src/components/MetadataPanel.tsx';
let content = fs.readFileSync(file, 'utf8');

const newSearchFn = `
  const handleSearch = async () => {
    setSearching(true);
    setSearchResults([]);
    try {
      const query = encodeURIComponent(\`\${searchArtist} \${searchTitle}\`);
      const res = await fetch(\`https://itunes.apple.com/search?term=\${query}&entity=song&limit=8\`);
      const data = await res.json();

      if (data.results && data.results.length > 0) {
        const mapped = data.results.map((r) => ({
          source: 'Apple Music Database',
          title: r.trackName || "",
          artist: r.artistName || "",
          album: r.collectionName || "",
          album_artist: r.artistName || "",
          explicit: r.trackExplicitness === 'explicit',
          year: r.releaseDate ? r.releaseDate.substring(0, 4) : "",
          track: String(r.trackNumber || ""),
          disc: String(r.discNumber || ""),
          genre: r.primaryGenreName || "",
          composer: "",
          isrc: "",
          duration: r.trackTimeMillis || 0,
          bpm: 0,
          key: "",
          has_lyrics: false,
          has_cover: !!r.artworkUrl100,
          cover: r.artworkUrl100 ? r.artworkUrl100.replace('100x100bb', '600x600bb') : ""
        }));
        setSearchResults(mapped);
      } else {
        const q = \`title=\${encodeURIComponent(searchTitle)}&artist=\${encodeURIComponent(searchArtist)}\`;
        const fallbackRes = await fetch(\`/api/search-metadata?\${q}\`);
        const fallbackData = await fallbackRes.json();
        if (fallbackData.results) setSearchResults(fallbackData.results);
      }
    } catch (e) {
      console.error("Apple Music search failed, trying AI fallback", e);
      try {
        const q = \`title=\${encodeURIComponent(searchTitle)}&artist=\${encodeURIComponent(searchArtist)}\`;
        const res = await fetch(\`/api/search-metadata?\${q}\`);
        const data = await res.json();
        if (data.results) setSearchResults(data.results);
      } catch (err) {}
    } finally {
      setSearching(false);
    }
  };
`;

content = content.replace(/const handleSearch = async \(\) => \{[\s\S]*?setSearching\(false\);\n    \}\n  \};/, newSearchFn.trim());

fs.writeFileSync(file, content);
