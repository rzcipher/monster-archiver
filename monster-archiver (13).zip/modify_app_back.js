const fs = require('fs');
let file = './monster-archiver-suite/webapp/src/App.tsx';
let content = fs.readFileSync(file, 'utf8');

// Add ArrowLeft import
content = content.replace(
  /import \{([^}]+)\} from "lucide-react";/,
  'import { $1, ArrowLeft } from "lucide-react";'
);

// Add closeTrack function
const closeTrackFunc = `
  const closeTrack = () => {
    setUploadedFile(null);
    setAnalysisResult(null);
    setMetadata(null);
    setLyricsText("");
    setDownloadUrl(null);
    setLibraryPath(null);
    setFinalizedPath(null);
    setPlayerSource("original");
  };

  // Analyze uploaded audio
`;
content = content.replace(/\/\/ Analyze uploaded audio/, closeTrackFunc);

// Add the back button
const backButtonStr = `              {/* CURRENT FILE HEADER SUMMARY */}
              <div className="flex flex-col gap-3">
                <button
                  onClick={closeTrack}
                  className="self-start px-3 py-1.5 bg-void-900 hover:bg-void-800 border border-void-700 rounded-lg text-xs font-semibold text-slate-300 transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  Back to Library
                </button>
                <div className="bg-void-900 rounded-xl border border-void-700 p-5 flex flex-wrap items-center justify-between gap-4">`;

content = content.replace(
  /\{\/\* CURRENT FILE HEADER SUMMARY \*\/\}\n\s*<div className="bg-void-900 rounded-xl border border-void-700 p-5 flex flex-wrap items-center justify-between gap-4">/,
  backButtonStr
);

// We need to close the extra div added
content = content.replace(
  /<\/div>\n\s*\{\/\* TABS \*\/\}/,
  '  </div>\n              </div>\n\n              {/* TABS */}'
);

fs.writeFileSync(file, content);
console.log("Updated App.tsx with closeTrack");
