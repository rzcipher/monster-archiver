const fs = require('fs');
let file = './monster-archiver-suite/webapp/src/App.tsx';
let content = fs.readFileSync(file, 'utf8');

// Replace line 536 and 538 exactly
content = content.replace(
  /<\/div>\n\s*\{\/\* TABS SELECTOR \*\/\}/,
  '</div>\n              </div>\n\n              {/* TABS SELECTOR */}'
);

fs.writeFileSync(file, content);
console.log("Fixed missing closing div in App.tsx");
