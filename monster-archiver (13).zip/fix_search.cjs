const fs = require('fs');
let file = '/app/applet/monster-archiver-suite/webapp/src/components/MetadataPanel.tsx';
let content = fs.readFileSync(file, 'utf8');

const regex = /const handleSearch = async \(\) => \{[\s\S]*?finally \{\s*setSearching\(false\);\s*\}\s*\};/;
const replacement = `const handleSearch = async () => {
    setSearching(true);
    setSearchResults([]);
    try {
      const q = \`title=\${encodeURIComponent(searchTitle)}&artist=\${encodeURIComponent(searchArtist)}\`;
      const fallbackRes = await fetch(\`/api/search-metadata?\${q}\`);
      const fallbackData = await fallbackRes.json();
      if (Array.isArray(fallbackData)) setSearchResults(fallbackData);
      else if (fallbackData.results) setSearchResults(fallbackData.results);
    } catch (e) {
      console.error("API search failed", e);
    } finally {
      setSearching(false);
    }
  };`;

content = content.replace(regex, replacement);
fs.writeFileSync(file, content);
