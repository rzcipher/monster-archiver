const fs = require('fs');
let file = './monster-archiver-suite/webapp/src/components/LocalFolderBrowser.tsx';
let content = fs.readFileSync(file, 'utf8');

const newRestoreUI = `
      {apiSupported && needsPermission && !scanning && localFiles.length === 0 && (
        <div 
          onClick={handleRestoreFSA}
          className="bg-deezer-900/10 hover:bg-deezer-900/20 border-2 border-dashed border-deezer-500/40 hover:border-deezer-500/70 rounded-xl p-10 mb-4 flex flex-col items-center justify-center cursor-pointer transition-all group shadow-lg"
        >
          <Folder className="w-12 h-12 text-deezer-400 mb-4 group-hover:scale-110 transition-transform" />
          <h3 className="text-xl font-bold text-white mb-2">Resume Local Library</h3>
          <p className="text-sm text-slate-400 text-center max-w-sm mb-6">
            Your folder is securely remembered! Browsers require a single click per session to reconnect to local files.
          </p>
          <button 
            className="px-8 py-3 bg-deezer-500 hover:bg-deezer-400 text-white text-sm font-bold rounded-lg shadow-lg shadow-deezer-500/20 transition-all group-hover:shadow-deezer-500/40"
          >
            Click to Reconnect Library
          </button>
        </div>
      )}
`;

content = content.replace(
  /\{apiSupported && needsPermission && !scanning && localFiles\.length === 0 && \([\s\S]*?<\/div>\n      \)\}/,
  newRestoreUI.trim()
);

fs.writeFileSync(file, content);
