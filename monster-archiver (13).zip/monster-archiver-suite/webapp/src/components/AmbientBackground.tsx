import React, { useEffect, useRef } from "react";
import { motion } from "motion/react";

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  baseAlpha: number;
}

export default function AmbientBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;
    let mouseX = -1000;
    let mouseY = -1000;
    let particles: Particle[] = [];

    const initParticles = () => {
      particles = [];
      // Calculate particle count based on screen area to maintain density
      const numParticles = Math.floor((window.innerWidth * window.innerHeight) / 12000); 
      for (let i = 0; i < numParticles; i++) {
        particles.push({
          x: Math.random() * window.innerWidth,
          y: Math.random() * window.innerHeight,
          vx: (Math.random() - 0.5) * 0.6, // Drift speed X
          vy: (Math.random() - 0.5) * 0.6, // Drift speed Y
          radius: Math.random() * 1.5 + 0.5, // Size between 0.5 and 2
          baseAlpha: Math.random() * 0.5 + 0.2 // Opacity
        });
      }
    };

    const resize = () => {
      const dpr = window.devicePixelRatio || 1;
      canvas.width = window.innerWidth * dpr;
      canvas.height = window.innerHeight * dpr;
      ctx.scale(dpr, dpr);
      canvas.style.width = `${window.innerWidth}px`;
      canvas.style.height = `${window.innerHeight}px`;
      initParticles();
    };
    
    window.addEventListener("resize", resize);
    resize();

    const handleMouseMove = (e: MouseEvent) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
    };
    window.addEventListener("mousemove", handleMouseMove);
    
    const handleMouseLeave = () => {
      mouseX = -1000;
      mouseY = -1000;
    };
    window.addEventListener("mouseleave", handleMouseLeave);

    const draw = () => {
      ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);
      
      const style = getComputedStyle(document.documentElement);
      const glowRgb = style.getPropertyValue('--glow-rgb').trim() || '255, 255, 255';
      
      const mouseConnectionRadius = 180;
      const particleConnectionRadius = 120;
      
      // Move and draw particles
      particles.forEach(p => {
        p.x += p.vx;
        p.y += p.vy;
        
        // Wrap around edges for infinite seamless space
        if (p.x < 0) p.x = window.innerWidth;
        if (p.x > window.innerWidth) p.x = 0;
        if (p.y < 0) p.y = window.innerHeight;
        if (p.y > window.innerHeight) p.y = 0;
        
        // Interaction: Gently nudge particles away from mouse to make it feel tangible
        if (mouseX !== -1000) {
          const dx = mouseX - p.x;
          const dy = mouseY - p.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 100) {
            p.x -= dx * 0.01;
            p.y -= dy * 0.01;
          }
        }
        
        // Draw the dot
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(${glowRgb}, ${p.baseAlpha})`;
        ctx.fill();
      });

      // Draw the "web" lines
      ctx.lineWidth = 0.6;
      for (let i = 0; i < particles.length; i++) {
        const p1 = particles[i];
        
        // 1. Connect particle to Mouse (The interactive web)
        if (mouseX !== -1000) {
          const dxM = mouseX - p1.x;
          const dyM = mouseY - p1.y;
          const distM = Math.sqrt(dxM * dxM + dyM * dyM);
          if (distM < mouseConnectionRadius) {
            ctx.beginPath();
            ctx.moveTo(p1.x, p1.y);
            ctx.lineTo(mouseX, mouseY);
            ctx.strokeStyle = `rgba(${glowRgb}, ${(1 - distM/mouseConnectionRadius) * 0.3})`;
            ctx.stroke();
          }
        }

        // 2. Connect particle to other particles
        for (let j = i + 1; j < particles.length; j++) {
           const p2 = particles[j];
           const dx = p1.x - p2.x;
           const dy = p1.y - p2.y;
           const dist = Math.sqrt(dx * dx + dy * dy);
           
           if (dist < particleConnectionRadius) {
             ctx.beginPath();
             ctx.moveTo(p1.x, p1.y);
             ctx.lineTo(p2.x, p2.y);
             ctx.strokeStyle = `rgba(${glowRgb}, ${(1 - dist/particleConnectionRadius) * 0.15})`;
             ctx.stroke();
           }
        }
      }
      
      animationFrameId = requestAnimationFrame(draw);
    };
    draw();

    return () => {
      window.removeEventListener("resize", resize);
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("mouseleave", handleMouseLeave);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-[-5]">
      {/* Interactive Free-Floating Particle Web */}
      <canvas 
        ref={canvasRef} 
        className="absolute inset-0" 
      />
      
      {/* Slow-moving, deeply blurred Aurora/Nebula orbs behind the web */}
      <motion.div
        animate={{
          scale: [1, 1.25, 1],
          x: [0, 80, 0],
          y: [0, -60, 0],
        }}
        transition={{ duration: 18, repeat: Infinity, ease: "easeInOut" }}
        className="absolute -top-[10%] -left-[10%] w-[50vw] h-[50vw] rounded-full bg-deezer-600/10 blur-[120px] mix-blend-screen"
      />
      
      <motion.div
        animate={{
          scale: [1, 1.3, 1],
          x: [0, -100, 0],
          y: [0, 80, 0],
        }}
        transition={{ duration: 24, repeat: Infinity, ease: "easeInOut", delay: 2 }}
        className="absolute top-[15%] -right-[10%] w-[45vw] h-[45vw] rounded-full bg-flow-500/10 blur-[140px] mix-blend-screen"
      />
    </div>
  );
}
